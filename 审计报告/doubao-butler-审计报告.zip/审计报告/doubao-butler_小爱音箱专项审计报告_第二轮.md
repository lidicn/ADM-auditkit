# doubao-butler 小爱音箱专项审计报告 · 第二轮

- **审计对象**：`E:\NAS\doubao-butler`（家庭 AI 管家），HEAD `b48cd2b`
- **审计日期**：2026-10-11
- **审计范围**：小爱语音链路（耳朵 → 路由 → 应答 → 发声 → 回声），以及所有把话推到小爱音箱的旁路
- **核心症状**：房间小爱执行指令后，会回复不相关内容
- **方法**：静态读函数体 + **在本机真跑判别式复现**（`python -I`，见附录 A）。凡标注「已复现」的条目，结论可逐字复核；凡只标注「读码」的条目，明确写出未验证的部分
- **与第一轮的关系**：本目录已有 `doubao-butler_小爱音箱专项审计报告.md`（X1–X8）。本文不重复 X1/X2/X3/X4/X5，只补**它的清单里没有、且同样指向「不相关内容」**的条目，并指出它里面**已过时**的一条

---

## 〇、一句话结论

「执行完指令又说不相关内容」在本仓里不是回声问题（v2.5 加注已实证主卧室 88h 自触发 0），而是**四条并存的旁路各自把一句独立生成的话推到了同一台小爱上**，且这四条旁路里只有一条登记了回声窗口、只有一条校验了房间。按可复现性排序：

1. **但ler 的应答文本本身就被判错了对象**（唤醒词子串误命中、房间 fallback、多轮上下文按角色共享）——话是对的，但**问的人不是它**；
2. **小爱执行了、但ler 又补一句 LLM 生成的话**（简单规则动词表缺口 + 时间查询漏出静默门）——用户听到两种声音，后者听起来就是"不相关"；
3. **有旁路播报腿没登记回声窗口**，但ler 自己的话被耳朵当作用户语音处理；
4. **小爱原生应答与 butler 应答的抢占闸门是"假设"而非"事实"**，小爱答了别的话时 butler 已静默退场，日志却显示"已处理"。

---

## 一、缺陷清单

| 编号 | 根因 | 位置 | 等级 | 可复现性 |
|---|---|---|---|---|
| **A1** | 唤醒词子串匹配 + 无最长优先，清洗破坏语义 | `dialog.py:198-208` | Critical | ✅ 已复现（10 例） |
| **A2** | 时间查询 `{"action":"none"}` 漏出小爱静默门 → 双播报 | `dialog.py:375-415` × `simple_rules.py:50` | Critical | ✅ 读码确证 |
| **A3** | pending ask 房间不匹配时 fallback 到**任意** ask，跨房抢答 | `ask.py:130-137` × `dialog.py:247-258` | Critical | ✅ 已复现（真跑） |
| **A4** | 简单规则动词表缺口：大量真实指令漏到 LLM，小爱先执行、butler 再补话 | `simple_rules.py:56-63,67-70,98-118` | Critical | ✅ 已复现（24 例） |
| **A5** | 多轮上下文只按 role 隔离，`butler` 的 9 台设备共享一份历史；ear 从不传 member | `dialog.py:76,417,444` × `xiaomi_ear.py:198,223` | Critical | ✅ 读码确证 |
| **A6** | 回声抑制**只有一个写入口**（`speak_as_role`），六条旁路播报腿全部绕过 | 8 个文件 17 处（§二·A6 表） | High | ✅ 已清点（脚本化） |
| **A7** | `note_speak` 对**所有** devices 登记，包括没播出去的那台；且写全局时间戳、ear 读设备字典 | `dialog.py:558-559,641-655` vs `xiaomi_ear.py:111,150` | High | ✅ 读码确证 |
| **A8** | 小爱静默分支不校验执行结果 → 小爱答了别的话时 butler 全程缺席，日志却显示"已处理" | `dialog.py:381-388` | High | ✅ 读码确证 |
| **A9** | `_match_audiobook_cmd` 用子串匹配 + 顺序错，普通对话被当成电子书指令吃掉 | `xiaomi_ear.py:245-263` | High | ✅ 已复现（10 例） |
| **A10** | 角色模式退出词写死为不存在的角色名，实际角色无一可退 | `xiaomi_ear.py:183-184,204-210` | High | ✅ 读码×配置比对 |
| **A11** | AF ask 的 room 为空时 `resolve()` 不过滤房间 → 9 台小爱齐响同一句 | `af_bridge.py:171-214` × `butler/devices.py:198-210` | Medium | ✅ 读码确证 |
| **A12** | `_emit_devices` 的 TV 委托分支与同批小爱设备并行播出，同句双声 | `dialog.py:561-577,585-620` | Medium | ✅ 读码确证 |
| **A13** | `sensor_map` 建连时固化一次；角色模式/回声窗口为类级字典，重启即丢 | `xiaomi_ear.py:56-66,111-113` | Medium | ✅ 读码确证 |
| **A14** | `intelligent_speaker` 内 19 行不可达死码，引用未定义变量 `message`，注释掉真身 `notify_message` 的判读依据 | `integrations/ha.py:342-360` | Low | ✅ 读码确证 |

---

## 二、逐条详证

### A1（Critical）唤醒词子串误命中 + 无最长优先，清洗后语义被破坏

`dialog.py:198-208`：

```python
def match_role_by_text(self, text: str):
    for role in rt.roles.all():
        if not role.enabled or not role.wake_words:
            continue
        for w in role.wake_words:
            if w and w in text:                      # ← 子串，句中任意位置
                cleaned = text.replace(w, "", 1).strip() if w else text
                return role, cleaned                 # ← 首个命中即返回，无最长优先
    return None, text
```

角色 `butler` 的 `wake_words` 是 `["豆包管家", "豆包"]`（`data/roles/butler.json`），**「豆包管家」排在「豆包」之前**。这既是子串误命中，也是"最长优先"缺失的双重缺陷。

本机复现（`python -I scripts/audit_xiaoai/repro.py`，角色表取仓库实际值，脚本内含修复版对照）：

```
现状（legacy）                                          修复版 A（句首+最长优先，推荐）
'我买了个豆包'      -> ('butler', '我买了个')              -> (None, '我买了个豆包')   ✅
'今天吃豆包'        -> ('butler', '今天吃')                -> (None, '今天吃豆包')     ✅
'打开豆包'          -> ('butler', '打开')                  -> (None, '打开豆包')       ✅
'豆包管家帮我查天气' -> ('butler', '帮我查天气')             -> ('butler', '帮我查天气')  ✅
'小凯，帮我写个道理'  -> ('agent_kevin', '，帮我写个道理')   -> ('agent_kevin', '帮我写个道理') ✅（旧版连逗号都剥不掉）
'豆包，帮我查天气'   -> ('butler', '，帮我查天气')          -> ('butler', '帮我查天气')  ✅
'凯凯很乖'          -> ('agent_kevin', '很乖')             -> ('agent_kevin', '很乖')   ❌ 残留
'小凯在不在'        -> ('agent_kevin', '在不在')           -> ('agent_kevin', '在不在') ❌ 残留
'小艾今天生日'      -> ('agent_emily', '今天生日')         -> ('agent_emily', '今天生日') ❌ 残留
'帮我写个道理'      -> (None, 原文)                        -> (None, 原文)             （"道理"不含"豆包"，侥幸）
'道理讲不讲'        -> (None, 原文)                        -> (None, 原文)
```

**⚠️ 必须如实写明的残留盲区**：句首锚定**解决不了「称呼 vs 描述」**。「凯凯很乖」与「凯凯，帮我写个道理」在字符串层完全同构——都是唤醒词紧跟非标点字符。试过的更严口径（修复版 B：要求唤醒词后紧跟逗号/句尾）能把三例全部压掉，但代价是**「豆包管家帮我查天气」这类最高频无逗号用法也一起失效**，属于把 bug 换成了更严重的 bug。所以这条缺陷的**完整修复不在这个函数里**，需要 A5 的"按人隔离"或一次廉价的意图判定（"称呼+谓述" vs "称呼+祈使"）来兜底。

本文 P0-1 只承诺修掉前 5 例（真正的误命中 + 语义破坏），后 3 例**明确留在未闭合项**（§六 第 6 条），⛔ 用"加了句首锚定"当"修好了"。

**与症状的对应**：房间小爱上「今天吃豆包」被路由给 butler，喂给 LLM 的入参是「今天吃」；「凯凯很乖」被 Kevin 角色当成点名并清洗成「很乖」——LLM 面对「很乖」只能自由发挥，回一句不相关的内容。**这条是"内容不相关"而不是"对象不相关"**：路由对了，语义没了。

> 第一轮报告 X2 已登记此项。本文补的是**仓库实际角色表的实测结果**：X2 举的「我买了个豆包」不是假设用例，是当前配置下就会触发的真实误命中（`butler.json` 的 `wake_words` 同时含「豆包管家」和「豆包」）。

---

### A2（Critical）时间查询漏出小爱静默门 → 同一台音箱连播两种声音

`dialog.py:375-415` 的静默门只认两个 action 名：

```python
simple_result = await check_simple_command(message, rt)
if simple_result:
    reply, action = simple_result
    if action.get("action") in ("call_service", "ask_device"):   # ← 只认这两个
        if source == "xiaoai":
            ...
            return {"ok": True, ..., "silent": True}
    elif action.get("action") == "skill_create_intent":
        ...
    spoken = await self._speak_transition(lambda: self.speak_as_role(...))   # ← 其余全走这里
    return {...}
```

而 `simple_rules._check_time` 返回的是 `{"action": "none"}`（`simple_rules.py:50`）——**不在 381 行的集合里**。所以：

- 用户对小爱说「现在几点了」；
- `_check_time` 命中（`_TIME_PATTERNS` 含 `几点了`），产出 `reply="现在是 14:23"`, `action={"action":"none"}`；
- 381 行不成立 → 落到 414 行 `speak_as_role` → butler 用 **edge-tts**（`butler.json` 的 `zh-CN-XiaoxiaoNeural`）播一句；
- 与此同时**小爱同学自己**也用自己的声音答了一遍。

结果：房间小爱连续播两句相同含义、**不同音色**的话。在小爱同学声音和但ler edge-tts 音色差别明显的家里，第二句听起来就是"音箱突然说了句不相关的话"。这条比 A1 更隐蔽，因为**但ler 的回复本身是完全正确的**——它错在"不该开口"。

同型漏口还有第二个：`action=="skill_create_intent"` 分支下小爱来源会播「你想创建什么技能？」，这条是设计意图；但 `_check_time` 这类**小爱同学必然原生应答**的查询，静默门从未覆盖。

---

### A3（Critical）pending ask 房间 fallback 跨房抢答

`ask.py:116-137`：

```python
candidates = [a for a in self._pending if a.room == room and not a.resolved]
if not candidates:
    # room 不匹配时，fallback 到任意 pending ask（手动触发 room 可能不准）
    candidates = [a for a in self._pending if not a.resolved]      # ← 拿别人的 ask 当自己的
    ...
    logger.info("ask room mismatch: armed=%s incoming=%s, fallback to any", ...)
```

而 `dialog.py:247-258` 的这个分支在 `on_wakeup` **最开头**——早于角色解析（263）、早于 `scope/private` 的 `bound_rooms` 校验（310）、早于简单规则（375）。也就是说房间校验形同虚设。

本机真跑（构造两条 pending：书房「要不要开空调」+ 客厅「要不要开电视」，调 `PendingAskManager.check`）：

```
check('书房')        -> room='书房'   q='要不要开空调？'   ✅ 同房
check('客厅')        -> room='客厅'   q='要不要开电视？'   ✅ 同房
check('Emily房间')   -> room='书房'   q='要不要开空调？'   ← 串房，取最早那条
check('')            -> room='书房'   q='要不要开空调？'   ← 空房间也串房
```

> 用例行程有个坑，写在这里免得下次踩：`PendingAsk` 的字段序是 `(room, question, brain, rt, created_at, timeout)`，第 5 位是 **`created_at`** 不是 `timeout`。直接 `PendingAsk("客厅","...",{},None,60)` 会把 `created_at` 写成 60（1970 年），`check` 的超时清理立刻把它删掉——那样 `check('客厅')` 返回书房那条，看起来像复现了串房，**其实是因为用例自己把客厅那条干掉了**。必须用关键字参数 `timeout=60`。脚本里已加注释。

**与症状的对应**：Emily 房间小爱上任何人随口一句话（包括一句"嗯"）都会被拿去回答书房的空调问题，`resolve_and_run` 走 LLM 第二轮产出 ≤60 字的回复并播报到 Emily 房间的小爱上。用户视角：**没问空调，卧室的小爱回答了空调**。空房间（`room=""`，来自 NR 老入口 `on_user_utterance` 取不到成员档案时）同样会串房。

补充一层放大：`llm_decide/engine.py:157-161` 只要 LLM 产出的文本里含 `?` 或 `？` 就会 `arm` 一条 pending ask（`ask_wait_seconds > 0` 时），而 `ask.py:84-114` 的 `_xiaomi_ask_flow` 会先 `button.press` 唤醒小爱、再 `text.set_value` 让小爱播问句。也就是说**这条链路本身就依赖小爱原生播报**，而 A3 让它能在**别的房间的小爱**上被认领——问在书房、答在卧室。

---

### A4（Critical）简单规则动词表缺口：小爱执行了，但ler 再补一句

`simple_rules.py:56-63` 的动词表只有 `开/关` + `灯/空调` 和 `打开/关闭` + `电视`，且 `:67-70` 的 `_TONE_EXCLUDE` 把 `关.*了` 这类结构挡在外面（`_TONE_EXCLUDE` 含 `没有|不用|不必|别` 与 `怎么|为什么|为何|？`，但**不挡**「把…了」句式，真正的问题是抽取式 `关(.*?)空调` 要求「关」紧贴）。

本机复现（`_check_device_control` 直接调用，24 例）：

```
命中（call_service / ask_device）          未命中 → 走 LLM
  '开灯'                 -> ask_device          '把灯关了'
  '关灯'                 -> ask_device          '把灯关掉'
  '关空调'               -> ask_device          '把空调关了'
  '开空调'               -> ask_device          '把客厅灯关掉'
  '打开空调'             -> ask_device          '关掉客厅电视'
  '打开电视'             -> ask_device          '空调调到26度'
  '打开书房灯'           -> call_service        '把空调调亮'
  '打开书房台灯'         -> call_service        '灯亮一点'
  '开一下厨房灯'         -> call_service        '音量调大'
  '空调打开吗'           -> 被 _TONE_EXCLUDE 挡
```

未命中那一列**全部落到 `agent.run`**（`dialog.py:437`），由 LLM 生成回复。而小爱同学对「把灯关掉」「空调调到26度」的理解能力远强于这 5 条正则——所以现实里发生的是：**小爱先用自己的声音执行完，但ler 紧接着用 edge-tts 补一句 LLM 生成的话**。

补的那句为什么经常"不相关"：`agent.py:85-115` 会往 system prompt 里注入【当前时间】【当前对话对象】【我记得的关于这个家】【当前在家】。当 butler 的 `output_devices` 覆盖全屋、且 LLM 拿到这些家庭上下文时，它对「把灯关了」这类已被小爱吃掉的指令，很容易产出涉及别的房间/别的成员的内容——或者干脆重复小爱已经说过的话。用户听的是"音箱又说了句没头没尾的话"。

顺带确证的两个次生缺陷（`_resolve_entity` 实跑，fake HA states 用仓库 `devices.json` 的真实命名风格）：

```
hint='闭'    -> 闭                     ← '关闭空调' 被 关(.*?)空调 抽成 '闭'，解析不到实体 → ask_device
hint='书房台' -> light.study_lamp       ← '打开书房台灯' 抽成 '书房台'，靠子串侥幸命中
hint='书房'   -> light.study_lamp       ← 子串侥幸，若 HA 里另有含"书房"的空调会串设备
```

`_resolve_entity`（`tools/devices.py:53-66`）在**指定 domain 无命中时会跨域重搜**；而 `_fast_route`（`core/agent.py:61-73`）调它时**根本不传 domain**。所以「打开空调」会带着空 domain 跨 `light`/`switch`/`media_player` 全域匹配 friendly_name。这条未取到真实 HA 状态，属**需真机定性**。

---

### A5（Critical）多轮上下文按角色共享，`butler` 的 9 台设备共用一份历史

`dialog.py:76` / `417` / `444`：

```python
self._role_history: dict[str, list] = {}          # key = role.id
...
history = list(self._role_history.get(role.id, []))
...
self._role_history[role.id] = hist[-12:]
```

`data/roles/butler.json` 的 `output_devices` 是 9 台：`tv_living, xiao_living, xiao_living_right, xiao_study, xiao_kevin, xiao_emily, xiao_touch8, xiao_master_bath, xiao_toilet`。这 9 台的每一次应答都写进同一份 `_role_history["butler"]`。

叠加第二刀：`xiaomi_ear.py:198` 与 `223` 调 `on_wakeup` 时**从不传 member**：

```python
await self.rt.dialog.on_wakeup(role_id, room, text, source_device=dev.id, source="xiaoai")
```

→ `member = ""` → 落到 `member or "家人"`。既无法按人隔离，`dedup` 也是按 `member` 记的（`dialog.py:664,716`），小爱链路的去重全部落在 "家人" 这一格。

**与症状的对应**：书房小爱问「打开书房台灯」→ 历史里写入；30 秒后 Kevin 房间小爱问「它多少钱」→ 命中同一个 butler 历史，"它"被解析成书房台灯。指代消解错了对象，回复内容自然"不相关"。**这是跨房间、跨人的串话，不是单点误判。**

同型还有一处：`on_tv_voice`（`dialog.py:489-499`）也写 `_role_history["butler"]`，且与 `on_wakeup` 的 butler 分支共享——电视遥控器语音按钮与全屋小爱是同一份历史。

---

### A6（High）回声抑制只有一个写入口，六条旁路播报腿全部绕过

仓库里把话推到小爱音箱的调用点共 17 处（脚本清点结果）：

| 文件:行 | 调用 | 是否登记回声窗口 |
|---|---|---|
| `core/dialog.py:598,607,611` | `play_xiaomi_url_once` / `tts_play_url` | ✅（经 `speak_as_role:655`） |
| `core/dialog.py:615,619` | `notify_message`（notify_text 模式） | ✅（同上） |
| `skills/runner.py:386` | `notify_message`（**角色分发主路径**） | ❌ |
| `skills/runner.py:346` | `notify_message` 到**固定** `settings.xiaomi_notify_entity` | ❌ |
| `decision/action_router.py:80` | `notify_message`（决策层 speak 动作） | ❌ |
| `tools/registry.py:1136` | `notify_message`（`speak_to_speaker` 工具，固定 `xiaomi_notify_entity`） | ❌ |
| `core/cron_task.py:483` | **直调 `_emit_devices`**，绕开 `speak_as_role` | ❌（见 A7） |
| `api/role_routes.py:95,101,105,109,113` | 四种播放方式 | ❌（只写了全局 `suppress_echo:119`） |
| `api/tts_routes.py:119,141,147,154` | `intelligent_speaker` / `tts_play_url` / `play_xiaomi_url_once` | ❌ |
| `audiobook/manager.py:304` | `play_xiaomi_url_once` | ❌（有自己那套逻辑，但与 ear 不同源） |
| `core/user_location.py:131,136` | `play_xiaomi_url_once` / `tts_play_url` | ❌ |

`skills/runner.py:386` 是最致命的一格：**任何带 `output_devices` 的技能（本仓全部技能角色都有）在房间小爱上播报，都不登记回声窗口**。而 `xiaomi_ear._handle_event` 的回声检查读的是 `self._echo_cooldown`（`xiaomi_ear.py:111,150`）。

后果链（与症状直接对应）：
1. 巡检/晨报/提醒技能经 `runner._dispatch_role` 让书房小爱播报「空调 28 度，注意开窗」；
2. 播报**未** `note_speak` → `_echo_cooldown` 无该设备条目；
3. 小爱的 conversation 传感器把 butler 自己的播报（或它自己补的一句「AI生成：…」之外的尾音）回传；
4. `_handle_event:149-154` 检查通过（无窗口）→ 继续走；
5. 若回传文本命中唤醒词（A1 的子串匹配，「AI生成：豆包管家…」这类前缀恰好会被 143-147 行挡住，但**只有 `startswith("AI生成：")` 精确前缀能挡**——小爱自己复述的「好的，我已为您打开」就挡不住）→ 被当成用户指令处理；
6. 房间小爱再答一句 → 用户视角：**说完一句又冒出一句不相关的内容**。

**旁路腿的第二个副作用是房间绑错**：`runner.py:346` 与 `butler/tools/registry.py:1136` 硬编码 `settings.xiaomi_notify_entity`，`butler/config.py:285` 的默认值是 `notify.xiaomi_cn_330794773_x08a_...`＝**书房那台**。无论事件发生在哪个房间，这两条腿都往书房小爱播。技能 `hello` 挂在 `butler` 角色上（`butler.json` 的 `skills: ["hello"]`），本应走 `runner:386` 的角色分发；一旦 `resolve_for_skill` 返回 None，就掉进 346 行——**在卧室喊管家，书房小爱开口**。

---

### A7（High）`note_speak` 登记范围与写读口径都不对

`dialog.py:641-655`：

```python
ok_devs = [dd.get("device", "") for dd in out if dd.get("ok")]
target = ",".join(ok_devs) if ok_devs else (room or "unknown")
try:
    await asyncio.to_thread(repo.add_turn, member, "butler", text, ..., target=target)
except Exception as e:
    logger.warning(...)
from butler.core.xiaomi_ear import XiaomiEar
for d in devices:                                            # ← 遍历全部，不是 ok_devs
    XiaomiEar.note_speak(d.id, hold_s=self._est_speak_secs(text))
```

两错：
1. **播报失败也压制**。`_emit_devices` 在 TTS 合成失败时返回 `{"ok": False}`（`dialog.py:616`），`play_xiaomi_url_once` 的云端 `code != 0` 时同样 `ok=False`（`599`）。这些设备**根本没出声**，却被写进 `_echo_cooldown`，压制该设备后续用户语音 ≥15s（`ECHO_COOLDOWN_S`）。用户对着音箱说话被吞，日志里没有任何一行说"没播出去"（`speak_as_role` 只在 `not devices` 时留痕，`634-638`）。
2. **写读口径两套且互不相认**。`_emit_devices:558-559` 写的是**实例级全局时间戳** `self._echo_until`，只有 `on_user_utterance:153` 和 `on_wakeup:242` 读它；`speak_as_role:655` 写的是**设备级类字典** `XiaomiEar._echo_cooldown`，只有 `_handle_event:150` 读它。全局那把窗在客厅播报后会**吞掉书房的正常语音**（漏答），而设备级那把窗只覆盖 `speak_as_role` 这一条路（A6）。

---

### A8（High）小爱静默分支把"未校验"伪装成"已处理"

`dialog.py:381-388`：

```python
if action.get("action") in ("call_service", "ask_device"):
    if source == "xiaoai":
        logger.info("simple device control from xiaoai, skip TTS (handled natively): %s", message[:30])
        self.state.set_state(DialogState.WAITING)
        self._spawn_idle()
        return {"ok": True, "role": role.id, "reply": "", "spoken": [], "simple_rule": True, "silent": True}
```

注释写「设备控制由小爱同学原生处理，butler 不重复 TTS」。这个假设成立的前提是**小爱真的执行了**，但代码从未校验过。三条现实路径让假设崩塌：

- **A4 的反面**：小爱把「把灯关了」理解为别的意图，或小爱问「您是要关闭哪个房间的灯？」——但ler 已在 388 行 return，全程缺席。用户只听到小爱那句**反问**，但ler 日志显示 `silent: True`，看起来"已处理"。
- **`ask_device` 的追问被静默吃掉**：`simple_rules.py:90` 产出的「要开哪个房间的灯？」在 xiaoai 来源下不播。但ler 本可以在这一步给用户一个可执行的引导（"说'开客厅的灯'"），却选择静默——用户以为"没人理我"，重说一遍，然后命中另一条正则。
- **执行结果无回读**：`ha.py:444-496` 的 `play_xiaomi_url_once` 返回体里有 `code`，但 `dialog.py:381-388` 的设备控制**不经过这条路**（小爱同学自己执行，butler 完全不可观测）。

这是最容易被误判为"butler 已应答"的**假绿**：日志 `silent: True`，用户听到的是小爱那句不相关的反问。

---

### A9（High）`_match_audiobook_cmd` 子串匹配 + 顺序错，普通对话被吃掉

`xiaomi_ear.py:159-175` 在 `audiobook.state.playing` 时**优先于唤醒词、优先于角色模式**执行，`:245-263` 用 `k in t` 子串匹配：

```python
if any(k in t for k in ["停止播放", "别播了", "不要播了", "停下", "闭嘴", "别念了", "不要念了"]):
    return "stop"
if any(k in t for k in ["暂停播放", "暂停", "先别播", "等一下", "等会儿"]):
    return "pause"
if any(k in t for k in ["继续播放", "继续", "接着播", "接着听", "继续念"]):
    return "resume"
```

本机复现：

```
'继续'        -> resume      '继续开灯'   -> resume      ← 想开灯，电子书被恢复了
'等一下'      -> pause       '往后翻'     -> next        ← "往后翻"本是翻页语义，但也会吞
'等会儿'      -> pause       '往前'       -> prev        ← "往前"出现在任何句子里都中招
'关掉'        -> None        '把空调关掉' -> None
'闭嘴'        -> stop        '再放一遍'   -> None
```

**与症状的对应**：电子书播放期间，用户对房间小爱说任何含「继续/等/往前/往后」的话——包括对小爱的正常对话、包括给家人的一句话——都被 `return` 掉，但ler 全程不答。反向的"没内容"同样表现为"答非所问"。而且这条路径**没有 `AI生成：` 过滤、没有回声窗口**（`ab.stop()/pause()/resume()` 都不经过 `speak_as_role`）。

---

### A10（High）角色模式退出词写死为不存在的角色名

`xiaomi_ear.py:183-184`：

```python
if any(kw in text for kw in ["关闭贾维斯", "关闭凯撒", "关闭露娜",
                              "退出", "退下", "没事了", "好了退下"]):
```

而仓库实际角色（`data/roles/*.json`）是：`butler`/豆包管家、`agent_lidicn`/小理、`agent_kevin`/小凯、`agent_emily`/小艾、`gu_anheng`/顾安恒、`xiaoyue`/晓月。**没有任何一个能被 `关闭贾维斯/关闭凯撒/关闭露娜` 关掉**——这三个名字在当前配置里不存在（角色收敛后已归档）。

结合 `_match_open_role`（`232-243`）用 `打开{name}` 进入，`data/roles` 里 6 个角色**都能进入**角色模式（`打开小理`、`打开小艾`、`打开豆包管家`…），但**没有一个能用对应语义退出**，只剩通用的「退出/退下/没事了」。

90 秒窗口内（`ROLE_MODE_TIMEOUT = 90`）该设备的**每一句话**都归进入模式时的角色，且：
- 不校验说话人（`mode` 只存 `role_id`，`113`/`207`）——用户「打开小艾」后走开，Kevin 的一句话会被小艾回答；
- 退出词表不含实际角色名 → 「关闭小艾」无效，用户以为退出了，其实没退。

**与症状的对应**：房间小爱在角色模式下，家人随口一句话被另一个房间的角色人格回答——典型的"不相关内容"。

---

### A11（Medium）AF ask 的 room 为空时全屋齐响

`af_bridge.py:171-186`：`room = ask.get("room", "")`，然后 `:207` `dialog.speak_as_role(role, prompt, room, ...)`。`butler/devices.py:198-210` 的 `resolve` 在 `room` 为空串时：

```python
if room and room != "*" and dev.room and dev.room != "*" and dev.room != room:
    continue
```

空串 → `if room` 为假 → **不过滤房间** → 返回 `butler.output_devices` 里全部 9 台。于是 AF 一条不带 room 的 ask 会让全屋小爱齐播同一句。同理 `resolve(role.output_devices, "")` 在 `speak_as_role:633` 也走这条路。

---

### A12（Medium）`_emit_devices` 电视委托与小爱并行播出

`dialog.py:561-577` 的 TV 分支在 `s.speak_target == "mqtt"` 时 `mqtt.publish(PUB_SPEAK_OUT, ...)` 交给 Node-RED 播电视；`585-620` 的小爱分支在同一 for 循环里**照常播**。两个分支独立，没有互斥 → 电视与小爱同时播同一句。而回声窗口只按 `devices` 遍历登记（A7），电视那台不受任何窗口约束。

---

### A13（Medium）`sensor_map` 固化一次；角色模式与回声窗口为类级字典

`xiaomi_ear.py:56-66`：`sensor_map` 在 `_connect()` 开头构建，随后 `async for msg in ws`（87 行）跑的是同一条长连接——WebUI 改 `devices.json` 新增/改绑音箱后，**不重连 HA websocket 就永不生效**（新增音箱不答、已删音箱仍答，且答的是旧房间归属）。

`111-113` 的 `_echo_cooldown` / `_role_mode` 是**类级字典**（注释已解释为何要放类体），因此进程内共享、但**重启即丢**，`butler/app.py:808-809` 每次重建实例。

---

### A14（Low）`intelligent_speaker` 内 19 行不可达死码

`integrations/ha.py:328-340` 的 `intelligent_speaker` 在 337/340 已 `return`，但 `342-360` 还挂着一段：

```python
        """通过 HA notify 平台让小爱音箱播报文本（如 xiaomi_miot 的 execute_text_directive）。"""
        if not self.s.ha_token:
            return "HA token 未配置"
        data = {"message": message}          # ← message 未定义
        ...
```

这段引用了未定义的 `message`，且**没有任何 `def` 包裹**——它是上一版 `notify_message` 的内联体，抽函数时被忘在原地。它不可达（前面已 return），所以运行时不炸；但它是**判读 `notify_message` 语义的误导源**：读者以为 `notify_message:362` 里 `intelligent_speaker(execute=True)` 的行为由这段代码决定，实际由 `xiaomi_miot` 的 `intelligent_speaker` service 决定。删掉这 19 行是零风险的卫生清理。

---

## 三、修复方案

### 批 P0：当天可上，四条独立、互不依赖

**P0-1 唤醒词：句首/断点锚定 + 最长优先**（改 `dialog.match_role_by_text`，同时替换 `xiaomi_ear:213` 与 `on_wakeup:297` 两处调用点）

下面这段与附录 A 脚本里的 `match_role_by_text_fixed` 是同一份代码（已在本机跑出 §二·A1 的对照结果）：

```python
_WAKE_BOUNDARY = re.compile(r"(?:^|[，,。.!！?？、；;：:\s])")
# 唤醒词与指令之间的合法分隔：逗号/空格/句尾。空串＝紧贴。

def match_role_by_text(self, text: str):
    """句首/断点锚定 + 最长唤醒词优先；只在真边界剥离，⛔ 整串 replace。

    旧实现的三条坏账：`w in text` 让「我买了个豆包」命中 butler；`replace(w,"",1)`
    把「豆包管家帮我查天气」洗成「管家帮我查天气」（角色 wake_words 同时含两者时，
    遍历顺序决定谁截胡）；首个命中即 return，无最长优先；`'，帮我写个道理'` 连
    前导逗号都剥不掉，直接喂给 LLM。
    """
    t = (text or "").strip()
    if not t:
        return None, text
    best = None  # (role, wake_word, pos)
    for role in get_runtime().roles.all():
        if not role.enabled or not role.wake_words:
            continue
        for w in role.wake_words:
            if not w:
                continue
            for m in re.finditer(re.escape(w), t):
                pos = m.start()
                # 只在行首、或前一个字符是断点时认作唤醒
                if pos == 0 or self._WAKE_BOUNDARY.fullmatch(t[pos - 1]):
                    if best is None or len(w) > len(best[1]):
                        best = (role, w, pos)
    if best is None:
        return None, text
    role, w, pos = best
    # 只剥离那一次出现，⛔ re.sub 全串 / str.replace
    cleaned = t[pos + len(w):].lstrip("，,。.、 \t").strip()
    return role, cleaned or text
```

验收用例（附录 A 脚本已跑通，逐字一致）：
`'我买了个豆包' → (None, 原文)`；`'打开豆包' → (None, 原文)`；`'豆包管家帮我查天气' → (butler, '帮我查天气')`；`'小凯，帮我写个道理' → (agent_kevin, '帮我写个道理')`。

**⛔ 声称修好的三例**：`'凯凯很乖'`、`'小凯在不在'`、`'小艾今天生日'`——这三例在修复版 A 下**仍然命中**，见 §二·A1 的残留盲区说明与 §六 第 6 条。本条只收前 5 例。

**P0-2 静默门改为白名单反向：xiaoai 来源下，除 `skill_create_intent` 外一律静默**（改 `dialog.py:375-415`）

```python
if simple_result:
    reply, action = simple_result
    # xiaoai 来源：小爱同学已原生应答，butler 唯一该开口的场景是"想创建什么技能"这种
    # 需要用户补描述的多轮流程。其余（设备控制/时间查询/技能创建意图）一律静默。
    # 旧实现按 action 名白名单放行 (call_service, ask_device)，`{"action":"none"}` 的
    # 时间查询从门缝漏出 → 小爱先答、butler 又用 edge-tts 答一遍（A2）。
    if source == "xiaoai" and action.get("action") != "skill_create_intent":
        logger.info("xiaoai-source simple rule, butler silent: action=%s text=%.30s",
                    action.get("action"), message[:30])
        self.state.set_state(DialogState.WAITING)
        self._spawn_idle()
        return {"ok": True, "role": role.id, "reply": "", "spoken": [],
                "simple_rule": True, "silent": True, "native_handled": True}
    ...
```

这样 `_check_time` 的 `{"action":"none"}` 被自动覆盖，**不再需要给每个 action 类型开洞**。

**P0-3 去掉 pending ask 的房间 fallback**（改 `ask.py:130-137`）

```python
candidates = [a for a in self._pending if a.room == room and not a.resolved]
if not candidates:
    # 房间不匹配⛔ fallback 到任意 ask：那会让"书房要不要开空调"被"Emily 房间"的
    # 一句闲话认领。宁可让 ask 超时——超时是可见的（on_timeout），串房是看不见的。
    logger.info("no pending ask for room=%s, pending rooms=%s",
                room, sorted({a.room for a in self._pending if not a.resolved}))
    return None
return min(candidates, key=lambda a: a.created_at)
```

代价：`arm` 时 `room` 传错的那条 ask 会静默超时。这是正确取舍——`dialog.py:247-258` 的位置在 `bound_rooms` 校验之前，fallback 等于**绕过了所有房间校验**。若确实需要容错，把容错做成显式开关（配置项 `PENDING_ASK_CROSS_ROOM`，默认关），并在日志里点名，而不是默认开。

**P0-4 `ask_device` 的追问不要用小爱口吻，且 xiaoai 来源下给出可执行引导**（改 `simple_rules._ask_device_reply` + `dialog.py:381-388`）

```python
def _ask_device_reply(domain: str, service: str, hint: str = "") -> str:
    """⛔ 写死「要开哪个房间的灯？」——那是但ler 的口吻，却由小爱音箱播报
    （notify_text 走小爱自带 TTS，tts_speak 走 edge-tts）。改成中性、可直接照着说的句式。"""
    verb = "打开" if service == "turn_on" else "关闭"
    noun = _DEVICE_NOUNS.get(domain, "设备")
    if hint:
        return f"「{verb}」没说清，请说：{verb}{hint}的{noun}"
    return f"请说清楚要{verb}哪个房间的{noun}，例如「{verb}客厅的{noun}」"
```

配合 P0-2，xiaoai 来源下这条追问依然静默——那就应该**不生成它**：xiaoai 来源直接返回小爱的原生结果，追问留给非小爱入口。

---

### 批 P1：一周内，收口发声与回声

**P1-1 回声窗口只有一个写入口**：把 `XiaomiEar.note_speak` 下沉到 `_emit_devices` 的设备级 return 里，`speak_as_role:651-655` 删掉，`cron_task.py:483` 不再直调 `_emit_devices`（改调 `speak_as_role`）。

```python
# dialog._emit_devices 的小爱分支，每个 dev 的真实结局处：
ok = ...
if ok:
    XiaomiEar.note_speak(dev.id, hold_s=self._est_speak_secs(text))   # 只有真播出去才压制
else:
    logger.warning("emit xiaomi NOT spoken device=%s detail=%.120s — 该设备不登记回声窗口",
                   dev.id, detail)                                    # ⛔ 静默
```

同时删掉 `dialog.py:558-559` 的全局 `suppress_echo`（那是 A7 的第 2 错），`on_user_utterance:153` / `on_wakeup:242` 的 `_echo_until` 判据改为按设备查 `XiaomiEar._echo_cooldown`：

```python
def _echo_left(self, device_id: str) -> float:
    return max(0.0, XiaomiEar._echo_cooldown.get(device_id, 0.0) - time.time())
```

`_echo_until` 只保留给**无法定位设备**的入口（`on_user_utterance` 的 NR 老路），并在日志里写明"这是全局兜底，可能误吞其他房间"。

**P1-2 六条旁路播报腿收口**：`skills/runner.py:386`、`runner.py:346`、`decision/action_router.py:80`、`tools/registry.py:1136`、`api/tts_routes.py`、`api/role_routes.py`、`core/user_location.py:131,136` 全部改调 `dialog._emit_devices(text, [dev], role)` 或 `speak_as_role`。唯一保留直调 `ha.notify_message` 的地方是 `_emit_devices` 自己。

`runner.py:346` 与 `butler/tools/registry.py:1136` 的**房间硬绑**必须一并改：删掉 `settings.xiaomi_notify_entity` 直取，改 `rt.devices.resolve(role.output_devices, room)`；解析不到就显式报「房间 X 无可出声设备」而不是落到书房。这条改完，「在卧室喊管家、书房小爱开口」消失。

**P1-3 多轮上下文 key 加设备维度**：

```python
# 旧：dict[str, list]  key=role.id → butler 的 9 台设备共用一份
# 新：dict[tuple[str,str], list] key=(role.id, source_device or "")
def _hist_key(self, role_id: str, source_device: str = "") -> tuple:
    return (role_id, source_device)

history = list(self._role_history.get(self._hist_key(role.id, source_device), []))
...
self._role_history[self._hist_key(role.id, source_device)] = hist[-12:]
# 顺手：容量上界，⛔ 随设备数无限涨（旧版按角色数是常数，新版按 role×device 是 O(n)）
if len(self._role_history) > 256:
    oldest = min(self._role_history, key=lambda k: self._role_history[k][-1].get("_ts", 0))
    del self._role_history[oldest]
```

配套：`xiaomi_ear:198,223` 补 `member` 参数（从 `rt.persona` 按房间反查在场成员，取不到传 `""`），让 `dedup` 与 `_role_history` 都能按人区分。

**P1-4 角色模式退出词动态化**（改 `xiaomi_ear:183-184`）

```python
def _build_exit_keywords(self, role_id: str) -> list[str]:
    """退出词由角色表生成，⛔ 写死在代码里。
    旧词表 ["关闭贾维斯","关闭凯撒","关闭露娜"] 在当前配置里没有一个对应角色存在
    （实际是 豆包管家/小理/小凯/小艾/顾安恒/晓月），6 个角色能进、0 个能用语义退出。"""
    role = self.rt.roles.get(role_id) if self.rt.roles else None
    names = []
    if role:
        names += [getattr(role, "name", "")] + list(getattr(role, "wake_words", []) or [])
    kws = [f"关闭{n}" for n in names if n] + [f"{n}退出" for n in names if n]
    return kws + ["退出", "退下", "没事了", "好了退下", "退下吧"]
```

同时把 `mode` 记上成员（`{"role_id", "expires_at", "member"}`），窗口内换人即退出——这是第一轮报告 X7 的落地，与 A10 同批做。

---

### 批 P2：两周，规则层与链路健壮性

**P2-1 简单规则设备动词表**（改 `simple_rules.py:56-73,98-118`）

```python
# 动词可选「把」前缀，可选句尾「了/吧」；抽取式不再要求动词紧贴设备名
_DEVICE_ON_PATTERNS = [
    (re.compile(r"(?:把)?\s*(?:开|打开|开启)(?:一下)?\s*(.{0,6}?)\s*灯"),
     re.compile(r"(?:把)?\s*(?:开|打开|开启)(?:一下)?\s*(?P<hint>.{0,6}?)\s*灯"),
     "light", "turn_on"),
    (re.compile(r"(?:把)?\s*(?:关|关闭|关上|关掉)(?:了)?\s*(.{0,6}?)\s*灯"),
     re.compile(r"(?:把)?\s*(?:关|关闭|关上|关掉)(?:了)?\s*(?P<hint>.{0,6}?)\s*灯"),
     "light", "turn_off"),
    # 空调 / 电视 同形
]
```

并把 `_TONE_EXCLUDE` 里与"了"无关的排除项复核一遍（当前它不挡「把…了」，真正挡掉「把灯关了」的是抽取式 `关(.*?)灯` 里「关」与「灯」之间允许任意字符——`re.search` 会命中「把灯关了」中的"灯关了"？不会：`关(.*?)灯` 要求「关」在「灯」**之前**。所以「把灯关了」必然不匹配。这就是缺口本身）。

**P2-2 `_resolve_entity` 必须传 domain**：`core/agent.py:70-73` 的 `_fast_route` 补 `domain`（按动词后的设备名先判类），否则跨域重搜（`tools/devices.py:53-66`）会让「打开空调」匹配到名字里含「空调」的任何设备。

**P2-3 `_match_audiobook_cmd` 改长度降序 + 句首锚定 + 设备控制优先**（改 `xiaomi_ear:159-175,245-263`）

```python
# 1) 电子书控制只在"明确是电子书指令"时拦截；命中 check_simple_command 的设备控制优先级更高
simple = await check_simple_command(text, self.rt)
if simple and simple[1].get("action") in ("call_service", "ask_device"):
    return None          # 交给正常对话/原生处理
# 2) 长词优先，⛔ 让「继续」截胡「继续开灯」
```

**P2-4 `sensor_map` 实时化**：`_handle_event` 里改为 `self.rt.devices` 反查（`sensor_map` 建连时构建一次的问题），或在 `_connect()` 里比对 `devices.json` 的版本号失效重建。

**P2-5 清掉 `ha.py:342-360` 的 19 行死码**（零风险）。

---

## 四、回归测试清单（可落为 unittest）

每条给出**输入 → 断言**，全部用仓库现有 `data/roles/*.json` 与 `data/devices.json` 的真实值构造 fixture，不 mock 配置。

| # | 断言 | 目标缺陷 |
|---|---|---|
| T1 | `match_role_by_text("我买了个豆包") == (None, "我买了个豆包")` | A1 |
| T2 | `match_role_by_text("打开豆包") == (None, "打开豆包")` | A1 |
| T3 | `match_role_by_text("豆包管家帮我查天气") == (butler, "帮我查天气")` | A1 |
| T3b | `match_role_by_text("小凯，帮我写个道理")[1] == "帮我写个道理"`（旧版返回 `'，帮我写个道理'`，前导逗号进了 LLM） | A1 |
| T4 | `on_wakeup("butler","客厅","现在几点了",source="xiaoai")` 的返回体 `silent==True and reply==""` | A2 |
| T5 | 书房 pending ask + `check("Emily房间")` 返回 `None` | A3 |
| T6 | `_check_device_control("把灯关了")` 返回非 None，且 `device_hint == "灯"`（不是 `""`） | A4 |
| T7 | `_check_device_control("空调调到26度")` 走 set_temperature 或至少 `action != None` 时不误判 | A4 |
| T8 | 「关闭空调」的 `device_hint == ""`（当前是 `"闭"`） | A4 |
| T9 | `on_wakeup` 对 xiaoai 来源写历史时 key 含 `source_device`，两台设备互不串 | A5 |
| T10 | `runner._dispatch_role` 播完后 `XiaomiEar._echo_cooldown[dev.id] > time.time()` | A6 |
| T11 | `speak_as_role` 在 `_emit_devices` 返回 `ok=False` 时**不**写 `_echo_cooldown` | A7 |
| T12 | `runner.py:346` / `butler/tools/registry.py:1136` 路径下，事件房间＝卧室时，书房设备的 `notify_message` **未被调用** | A6 |
| T13 | `_match_audiobook_cmd("继续开灯") is None`（播放中） | A9 |
| T14 | `_match_audiobook_cmd("往后") is None` 或要求句首匹配 | A9 |
| T15 | `roles = {6 个真实角色}` 时，进入 `打开小理` 后，`_build_exit_keywords` 含「关闭小理」 | A10 |
| T16 | `speak_as_role(role, "测试", room="", member="系统")` 的 `devices` 长度 **== 1**（不返回 9 台） | A11 |
| T17 | `_emit_devices` 在同批含 tv＋xiaomi 且 `speak_target=="mqtt"` 时，电视委托后小爱分支有互斥判定 | A12 |
| T18 | `xiaomi_ear._handle_event` 对 `sensor_map` 缺失但 `rt.devices` 存在的实体仍能路由 | A13 |
| T19 | `intelligent_speaker` 函数体内无引用未定义名的语句（静态断言：`py_compile` + AST 名检查） | A14 |

> T10–T12 是「回声窗口收口」的机械化守卫：三条全绿才算 P1-1/P1-2 真的闭合。T16 是关键——它同时守住了 A11 和 A1（`resolve(..., "")` 不过滤房间是同一处代码的两条后果）。

---

## 五、观测口径（真机验收）

四条日志锚点，按现有日志格式即可检索，不需要新增埋点：

1. `ear [entity|room]` —— 耳朵收到什么（`xiaomi_ear.py:157`）
2. `ear echo-suppressed` —— 被回声窗口挡掉的（`152`）
3. `emit xiaomi direct result device=... code=...` —— 真播出去了吗（`dialog.py:601`）
4. `xiaoai-source simple rule, butler silent` —— P0-2 落地后，静默是否按预期发生（新增）

验收场景（对应症状本身）：

| 场景 | 操作 | 期望 |
|---|---|---|
| 指令后不补话 | 书房小爱说「把灯关了」 | 小爱执行；**但ler 全程不出声**（P0-2）；日志有 `butler silent` |
| 时间查询不双声 | 任意小爱说「现在几点了」 | 只有一种声音答一次（P0-2） |
| 跨房不串话 | 书房 pending ask 挂起，Emily 房间随便说句闲话 | Emily 房间小爱**不回答空调**（P0-3） |
| 唤醒词不误命中 | 客厅小爱说「今天吃豆包」 | 不触发但ler（P0-1） |
| 回声不被自吞 | 让巡检技能在书房小爱播一句，立刻对同一台说话 | 用户语音不被吞、播报回声不被当指令（P1-1/P1-2） |
| 房间不错绑 | 在主卧室喊管家（走无角色技能分支） | 书房小爱**不响**（P1-2 第二条） |
| 角色模式可退 | 说「打开小理」，再说「关闭小理」 | 90s 窗口被取消（P1-4） |

---

## 六、本文未覆盖 / 明确留待定性

1. **`xiaomi_miot.intelligent_speaker` 的服务端语义未核验**。`ha.py:328-340` 传 `execute=True`，本仓内没有 `xiaomi_miot` 的集成源码（检索超时，未取到本地副本），因此**无法确认 `execute=True` 是"小爱执行指令"还是"小爱朗读文本"**。若是后者（纯朗读），那么 `notify_message` 这条路径与 A6 的关系完全改变——它可能根本不产生"小爱原生应答"，A8 的假设也就不成立。**这一格必须由真机验证后再裁**，本文把它写成"读码确证"以外的推断，⛔ 当作结论。
2. **`_resolve_entity` 的跨域重搜未取真实 HA 状态**，只跑了 fake states（A4 末段）。真实 friendly_name 语料里若有含"空调/灯"的设备名，命中面会更大。
3. **`check_simple_command` 的 6.2% 认下率**（v2.5 加注引用：1,003 次里只认 62 次）来自盘上日志统计，本文未复核原始日志，只复核了判别式的行为。
4. **Node-RED 侧 `nr_flow_butler.json` 的 payload 字段**未读，因此 P0-1 里 `on_user_utterance` 能否拿到 `source_device` 属待确认（第一轮报告 X1 同此）。
5. **`role_routes.py:95-113` 与 `tts_routes.py` 的完整路径**未逐行审计，只在旁路表里登记了行号。
6. **A1 的三例残留盲区未闭合**：`'凯凯很乖'`、`'小凯在不在'`、`'小艾今天生日'` 在 P0-1 的修复版 A 下**仍然命中**。这是「称呼 vs 描述」的语义判定问题，纯字符串规则无法区分（详见 §二·A1 末尾）。已验证更严口径（修复版 B：要求唤醒词后紧跟逗号/句尾）能压掉这三例，但**同时会让最高频的无逗号用法「豆包管家帮我查天气」失效**，因此不作为方案。真正闭合需要一条廉价的「称呼+谓述 / 称呼+祈使」判别（可用 `agent_llm` 之外的规则先试：谓述词表 + 无宾语祈使动词表），或依赖 A5 的按人隔离把后果降为"答给错的人"而不是"答错内容"。**本条明确登记为未闭合，⛔ 用 P0-1 交付时宣称 A1 已修好。**

---

## 七、与第一轮专项报告的差异

- **X6 已过时**。第一轮说 `on_wakeup` 的 docstring 宣称校验 `bound_rooms` 而函数体缺失。当前 `dialog.py:310-314` **确实有**该校验（`scope_private` 分支），第一轮写的是旧树的结论。
- **X1/X2/X3 仍成立**，本文补的是：X2 的实测用例在当前角色表下就是真实误命中（不只是理论）；X1 与 X3 的**下游后果**由本文 A5/A6/A12 补全（第一轮止步于"路由错"，没追到"错完之后回声窗口也错、历史也串"）。
- **A2/A3/A6/A8/A10/A11 是本轮新增**，都不在第一轮清单里，但都直接指向「执行了指令又说了一句不相关的话」。其中 A2 和 A8 是**同一个假设的两面**——A2 是但ler 不该说话时说、A8 是小爱说了别的话时但ler 没说话；两者共同点是**代码按 action 名判断"该不该开口"，而"小爱同学会不会原生应答"这个真实前提从未被校验过**。

---

## 附录 A：复现脚本与实跑输出

脚本已落盘：`scripts/audit_xiaoai/repro.py`（不在本文内嵌，避免文档与代码双写漂移）。
从仓库根运行：`python -I scripts/audit_xiaoai/repro.py`（`-I` 隔离宿主目录的 `json.py` 之类污染）。

脚本包含四个部分：A1 的**现状 / 修复版 A / 修复版 B 三列对照**（A/B 两版都是可直接落地的代码，用来量化"残留盲区"与"更严口径的代价"）、A4 的设备规则判别式、A3 的 pending ask 真跑、A9 的电子书指令。

本次实跑输出（HEAD `b48cd2b`，Python 3，`python -I`）关键片段：

```
=== A1 唤醒词：现状 / 修复版A(推荐) / 修复版B(更严，验证残留盲区规模) ===
  '我买了个豆包'            legacy=('butler', '我买了个')          fixedA=(None, '我买了个豆包')       fixedB=(None, '我买了个豆包')
  '今天吃豆包'              legacy=('butler', '今天吃')            fixedA=(None, '今天吃豆包')         fixedB=(None, '今天吃豆包')
  '豆包管家帮我查天气'        legacy=('butler', '帮我查天气')         fixedA=('butler', '帮我查天气')      fixedB=(None, '豆包管家帮我查天气')  ← B 的代价
  '小凯，帮我写个道理'         legacy=('agent_kevin', '，帮我写个道理') fixedA=('agent_kevin', '帮我写个道理') fixedB=('agent_kevin', '帮我写个道理')
  '凯凯很乖'                legacy=('agent_kevin', '很乖')         fixedA=('agent_kevin', '很乖')      fixedB=(None, '凯凯很乖')        ← A 的残留
  '小艾今天生日'             legacy=('agent_emily', '今天生日')      fixedA=('agent_emily', '今天生日')    fixedB=(None, '小艾今天生日')      ← A 的残留

=== A4 设备规则（未命中 = 走 LLM = 小爱执行后但ler 补话）===
  '把灯关了'     -> None          '把空调关了'   -> None         '空调调到26度' -> None
  '把灯关掉'     -> None          '把客厅灯关掉'  -> None         '灯亮一点'     -> None
  '把客厅灯关掉' -> None          '关掉客厅电视'  -> None         '音量调大'     -> None
  '关闭空调'     -> ('好的，关闭了。', 'call_service', '闭')      ← device_hint 抽成"闭"
  '打开书房台灯' -> ('好的，打开了。', 'call_service', '书房台')   ← 靠子串侥幸命中

=== A3 pending ask（应只返回同房间）===
  check('书房')        -> room='书房'   q='要不要开空调？'   ✅
  check('客厅')        -> room='客厅'   q='要不要开电视？'   ✅
  check('Emily房间')   -> room='书房'   q='要不要开空调？'   ← 串房
  check('')            -> room='书房'   q='要不要开空调？'   ← 空房间也串房

=== A9 电子书指令（期望：含设备动词的句子应为 None）===
  '继续'      -> resume     '往后翻'    -> next      '把空调关掉' -> None
  '等一下'    -> pause      '关掉'      -> None      '再放一遍'   -> None
  '往前'      -> prev       '继续开灯'   -> resume   ← 想开灯，电子书被恢复了
```

§二 各节的内联输出与本次实跑逐字一致（A1 节补记了修复版 A/B 两列，§六 第 6 条补记了残留盲区）。
