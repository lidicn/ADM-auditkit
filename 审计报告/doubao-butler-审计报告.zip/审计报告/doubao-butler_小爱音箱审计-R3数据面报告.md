# doubao-butler 小爱音箱审计 · R3 数据面与桥接层报告

> 轮次：R3（NR 桥接 + 事件流 ROOM_MAP + simple_rules）
> 日期：2026-10-11
> 结论：**X1 铁证坐实（老腿物理上无法透传设备）；新发现 X9（ROOM_MAP 子串顺序缺陷）。**

---

## 一、X1 铁证：NR 老腿**物理上**无法透传设备身份

### 证据链（逐跳）

```
小爱 ASR ──▶ topic「xiaomi/asr」(裸 topic，无房间维度)
         ──▶ fn_voice 组装事件
         ──▶ topic「butler/event/voice」
         ──▶ dialog.on_event → on_user_utterance(member, text)
```

**`nr_flow_butler.json:fn_voice` 原文：**

```javascript
const m = (msg.payload && typeof msg.payload === 'object') ? msg.payload : {};
const text = (m.text || ...).toString().trim();
if (!text) return null;
const member = m.member || '';
msg.topic = 'butler/event/voice';
msg.payload = { member, text };      // ← 只有 member + text，⛔ 无 device/room/entity
return msg;
```

**`dialog.on_event` 原文（:96）：**

```python
await self.on_user_utterance(member, str(payload.get("text") or ""))
```

### 结论

X1 不只是「`on_wakeup` 漏传 `source_device`」——**更上游的 NR function 节点就没采集设备身份**。
即便把 `on_user_utterance` 改成透传，**也没有数据可透**。

### 与「新腿」对比

| | 新腿（HA 直连） | 老腿（NR） |
|---|---|---|
| 入口 | `xiaomi_ear._handle_event` | `dialog.on_event` |
| 设备身份 | `dev.id`（来自 `ha_sensor` 映射） | **无** |
| 房间 | `dev.room`（设备物理房间） | 成员档案房间 |
| 传参 | `on_wakeup(..., source_device=dev.id)` | `on_wakeup(...)` 无设备 |

**这是「同一系统两套耳朵、两套能力」的结构性问题。**

### 修复（两条路，择一）

**路线 A（推荐）：废弃 NR 老腿，统一走 HA 直连**
- `nr_flow_butler.json` 的「小爱 ASR → butler/event/voice」分支删除或禁用
- 所有小爱经 `ha_sensor` 配置由 `xiaomi_ear` 订阅
- 理由：新腿已具备设备/房间/回声/角色模式全套能力，老腿是能力残缺的遗留

**路线 B：补齐 NR 采集**
- `in_asr` 改订阅**带房间维度**的 topic（如 `xiaomi/asr/<room>`）或改 `server-state-changed` 监听各房间 conversation sensor
- `fn_voice` payload 增补 `device_id` / `room`
- `on_event` voice 分支读取并透传 `source_device`
- `on_user_utterance` 增加 `source_device` 形参

**若 NR 老腿实际已停用，X1/X3 降为「死代码缺陷」**（不影响现网，但需清理以免误接）。

---

## 二、X9（新发现，Medium-High）ROOM_MAP 子串匹配顺序缺陷

### 证据 —— `event_stream.py:40`

```python
ROOM_MAP = {
    "living": "客厅", "kitchen": "厨房", "study": "书房",
    "bedroom": "主卧室", "kevin": "Kevin房间", "emily": "Emily房间",
    "bath": "卫生间", "toilet": "卫生间", "master_bath": "主卧室浴室",
}

def _infer_room(entity_id: str) -> str:
    e = entity_id.lower()
    for key, room in ROOM_MAP.items():      # ← dict 保序遍历，先命中先返回
        if key in e:
            return room
    return ""
```

### python_exec 实测（本机验证）

```
binary_sensor.master_bath_door   -> 卫生间      ← 应为「主卧室浴室」
binary_sensor.bath_door          -> 卫生间      ← 正确
binary_sensor.bedroom_humidity   -> 主卧室      ← 正确
sensor.xiaomi_s12_10ca_conversation -> (空)     ← 无任何 key 命中
```

**`bath` 在 `master_bath` 之前**（实测确认 `True`），因此 `"bath" in "master_bath_door"` 先命中，
`master_bath` 条目**永远不可达**（死条目）。

### 与 X2 同族

这是**子串匹配 + 顺序敏感**的同一类缺陷（X2 是唤醒词子串，X9 是房间 key 子串）。
根因相同：**「包含」判定在多义前缀下必须「最长匹配优先」**。

### 影响面

`_infer_room` 被 `event_stream` 用于写 `home_events.room`（:169 快照、:247 事件）。
主卧室浴室的传感器事件被记为「卫生间」→ 场景推理 / 决策层的房间归因错误。
严重度 Medium-High（取决于是否用 room 做场景判断）。

### 修复

```python
def _infer_room(entity_id: str) -> str:
    e = entity_id.lower()
    best_key, best_room = "", ""
    for key, room in ROOM_MAP.items():
        if key in e and len(key) > len(best_key):   # 最长匹配优先
            best_key, best_room = key, room
    return best_room
```

顺带把 `sensor.*_conversation` 类也纳入（它们当前推断为空），或改用 `devices.json` 的 room 字段。

---

## 三、X3 澄清（数据面）

老腿 room 来自 `member_by_name(member).room`（成员档案）。
若 NR 的 `fn_voice` 连 `member` 都常为空（`const member = m.member || ''`），
则 `on_user_utterance` 里 `if member: mark_present` 跳过、`mc` 为 None、`room` 为空，
最终 `match_role_by_room(None)` 返回 None → 回退 butler。

**即：老腿在 member 缺失时，连房间都推不出来，直接退化成「无房间的 butler 应答」。**

---

## 四、X4 补充：`source == "xiaoai"` 时设备控制静默

`dialog.py:383-387`：

```python
if source == "xiaoai":
    logger.info("simple device control from xiaoai, skip TTS (handled natively)")
    return {"ok": True, "role": role.id, "reply": "", "spoken": [], "simple_rule": True, "silent": True}
```

设计意图：设备控制由小爱原生处理，butler 不重复 TTS（防双重播报）。
**但注意**：这里只在 `simple_rules` 命中设备控制时静默。若用户说的是**非简单命令**
（走 LLM 的请求），butler 仍会应答——此时小爱原生也已应答，**双应答**（X4 的另一面）。

---

## 五、覆盖率更新（R3 后）

```
听话腿 ear      75% → 75%
说话腿 dialog   70% → 78%  （on_event 入口 + source==xiaoai 分支确认）
发声腿 ha.py    45% → 45%  （R3 未推进，留 R4）
NR 桥接          0% → 100% （✅ 读完，X1 铁证）
事件流 ROOM_MAP  0% → 100% （✅ X9 新发现）
simple_rules     0% → 100% （✅ 读完）
真跑            10% → 10%  （未跑）
```

---

## 六、缺陷总表（R1+R2+R3 累计）

| 编号 | 缺陷 | 位置 | 等级 | 轮次 |
|------|------|------|------|------|
| X1 | NR 老腿无设备身份（**上游 fn_voice 就没采集**） | nr_flow + dialog:96/193 | **Critical** | R1→R3铁证 |
| X2 | 唤醒词子串匹配 + replace 破坏语义 | dialog:205-209 | Critical | R1确认 |
| X4 | wake_button 仅角色命中才按；非简单命令双应答 | ear:191/215 + dialog:383 | High | R1确认 |
| X3 | 老腿 room 取成员档案（member 空则退化为无房间） | dialog:146+ | High | R2降级/R3澄清 |
| **X9** | **ROOM_MAP 子串顺序缺陷（master_bath→卫生间）** | **event_stream:40** | **Medium-High** | **R3新** |
| X6 | text 腿不校验 bound_rooms（docstring 漂移） | dialog:on_wakeup | Medium | R2降级 |
| ~~X5~~ | ~~回声抑制不一致~~ | — | — | R2撤销 |
| ~~X7~~ | ~~角色模式不校验成员~~ | — | — | R2撤销 |
| X8 | sensor_map 建连一次 | ear | Low | R1 |

---

## 七、R4 待办（运行时真跑，收口）

1. **X1 真跑**：构造 payload `{member:"lidicn", text:"管家，现在几点"}` 注入 `on_user_utterance`，
   断言 `source_device` 为空 → 观察 `speak_as_role` 回退到 `resolve(output_devices, room)` 的行为。
2. **X9 真跑**：`python -c "from butler.core.event_stream import _infer_room; print(_infer_room('binary_sensor.master_bath_door'))"`
3. **X2 真跑**：直接调 `match_role_by_text("我买了个豆包")` 断言误命中。
4. 跑 `pytest tests/test_audit_1011_batch192_echo_cooldown_legs.py` 确认基线绿。

---

## 八、方法论（第三轮验证）

R3 用 **python_exec 真跑 `_infer_room`** 而不是「读代码猜顺序」——`bath 在 master_bath 之前: True`
是一行实测，比肉眼扫 dict 可靠。**凡涉及「遍历顺序 / 集合语义 / 数值边界」的判定，都应真跑**。
这是 R4「强制真跑轮」的又一次预演。
