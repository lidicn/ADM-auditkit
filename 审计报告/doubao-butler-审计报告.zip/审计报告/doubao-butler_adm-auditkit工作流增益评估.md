# doubao-butler × ADM-auditkit 工作流增益评估

- **审计对象**：`E:\NAS\ADM-auditkit`（工作流本身）→ 用于审计 `E:\NAS\doubao-butler`
- **评估日期**：2026-10-11
- **基线**：本人上一轮手工审计产出的 14 条缺陷（`doc/审计报告/doubao-butler_小爱音箱专项审计报告_第二轮.md`，A1–A14）
- **方法**：不动原仓库，`cp -r` 到 `C:\Users\lidicn\AppData\Local\Temp\auditkit_run` 后实验。原仓库 `git status` 已复核未受影响。
- **结论先行**：**对发现 butler 缺陷的增益接近零；对审计审计工具自身的增益显著。**

---

## 一、一句话结论

机器跑了 round-021，报 **3744 条 findings**。但其中：

| 指标 | 数值 |
|---|---|
| 精确率（抽样 40 条 / 最大规则） | **25%** |
| 落在快照/备份/测试树的 findings（engine_rules） | **69.1%**（1391 / 2014） |
| 落在快照/备份/测试树的 findings（generic_text） | **86.1%**（1489 / 1730） |
| 落在快照/备份/测试树的 findings（合计） | **76.9%**（2880 / 3744） |
| 落在**活的 `butler/`** 的 findings | **17.5%**（654 / 3744） |
| 命中上一轮手工报告的 5 个真实缺陷位置 | **0 / 5** |
| 被硬编码关掉的 legacy 分析器 | **20 / 21** |
| `doubao-butler` 专属规则 | **0 条** |

估一下真实有效产出：`3744 × 0.25（精确率）× 0.175（落在活的 butler/）≈ 160 条`。再考虑其中相当部分是 `except: return err(...)` 这类 fail-closed 契约误判（25% 真阳性里也混着测试目录），**有效量级约 100–150 条**，且散落在 `tests/`、`scripts/` 这类我人工审计本来就会跳过的目录里。

### 数字勘误（本报告的三轮自我修正，保留记录）

这份报告里的污染比例我改了三轮，每一版都是错的，错法不一样：

| 版本 | engine_rules | generic_text | 错在哪 |
|---|---|---|---|
| 第 1 版 | 67.9%（1367） | 77.1%（1335） | generic_text 只统计了 `workorders/` 一个目录 |
| 第 2 版 | 67.9%（1367） | 82.9%（1435） | 改成统计 `workorders`/`_scratch_1002`/`butler.local_backup` 三个，仍漏 `tmp`/`archive`/`tests`/`readings` |
| **本版** | **69.1%（1391）** | **86.1%（1489）** | 用完整 8 个快照标记（`backup`/`snapshot`/`scratch`/`tmp`/`workorders`/`readings`/`archive`/`tests`） |

第 3 版数字（69.1% / 86.1%）与 `scripts/audit_xiaoai/per_source.py` 的输出逐字一致，可复现。

**有效量级估算也从第 1 版的"约 300 条"下调到"约 100–150 条"。结论方向从未变过（机器增益接近零），但幅度原来低估了。** 这也是为什么本报告把每轮的错版数字都留在表里 —— 如果只留最后一版，读者无法判断这个数字被改过多少次。

**这个工作流当前形态对 doubao-butler 的增量发现能力 ≈ 0。** 它的价值不在 findings，而在下面第三节——它暴露了自己的 6 个失效点。

---

## 二、我做了什么（实验设计）

```
1) cp -r E:/NAS/ADM-auditkit  →  /tmp/auditkit_run        # 原仓库不动
2) python auditkit selftest                                      # 第一步就红了
3) 定位 BOM 根因，去除 2 个样本的 BOM，重跑 selftest             # 转绿
4) python auditkit profile E:/NAS/doubao-butler --json          # 画像
5) python auditkit round db_default --path E:/NAS/doubao-butler --round 21
6) 分析产物：精确率抽样 / 快照树污染 / cross-check 手工缺陷
7) 绕过 include_legacy=False，手动跑 legacy 分析器对照
```

配套脚本已落盘（可复现）：
- `scripts/audit_xiaoai/analyze_round.py` —— 分析一轮产物（污染比例、按规则分布、cross-check）
- `scripts/audit_xiaoai/precision_check.py` —— 按绝对行号回溯源码，四分类抽样精确率

---

## 三、真增益：工作流自身的 6 个失效点

这 6 条是我上一轮人工审计**不可能**发现的（它们不在但ler 的代码里，在工作流自己的代码/样本里）。这是本次唯一的实质产出。

### W1（Critical）UTF-8 BOM 让 20/21 个分析器静默失效，且能存活到"自检全绿"

**证据链**：

`selftest/cases/dirty/sample.py` 与 `sample.ts` 首 3 字节是 `\xef\xbb\xbf`：

```python
src = Path('selftest/cases/dirty/sample.py').read_bytes()
b.startswith(b'\xef\xbb\xbf')   # True
ast.parse(src.decode('utf-8'))  # SyntaxError: invalid non-printable character U+FEFF (line 1)
ast.parse(src.decode('utf-8-sig'))  # OK
```

而分析器读文件用的是：

```python
# legacy/analyzers/ast_defects.py:71
tree = ast.parse(path.read_text(errors="ignore"))
```

`errors="ignore"` 只影响**解码**，不处理 BOM —— `\ufeff` 作为 U+FEFF 字符进入源码串，`ast.parse` 仍抛 `SyntaxError`。该异常被分析器的循环吞掉 → 报 `{"files": 1, "total": 0}` → 自检判 `0 命中 = 规则失效`。

实测修复效果（去 BOM）：

```
ast_defects  dirty: 0 命中  →  3 命中
全 21 个分析器 dirty 总命中:  0  →  116
clean 样本命中: 0（无假阳性回归）
selftest: FAIL(exit 1) → OK(exit 0)
```

**修复 diff（一行，改 `legacy/analyzers/_common.py` 或各分析器的读文件处）**：

```diff
- tree = ast.parse(path.read_text(errors="ignore"))
+ tree = ast.parse(path.read_text(encoding="utf-8-sig", errors="ignore"))
```

`utf-8-sig` 会剥离 BOM，对无 BOM 文件是 no-op，零副作用。**这一行没写，等于 21 个分析器里 20 个从第一天起就是坏的。**

**它为什么能存活至今** —— 见 W2。

### W2（High）`round` 不跑 `selftest`，"开工前必跑"只是 README 口头约定

`auditkit:113` 的 `cmd_round` 从 122 行"画像"直接到 162 行"引擎分派"，中间**没有任何 selftest 调用**。`cmd_round` 里 `grep selftest` 零命中。

也就是说 W1 这种"分析器全坏但退出码 0"的状态，`round` 会安静地跑完并产出看起来正常的 `summary.json`。README 第六节把自检叫"最重要的一块"，但工作流没有强制点。

**修复**：`cmd_round` 开头加一道硬门，自检失败即返回非零：

```python
st = subprocess.run([sys.executable, str(SELFTEST / "run_selftest.py")],
                    capture_output=True, text=True, timeout=600)
if st.returncode != 0:
    print("[block] 自检未通过，拒绝出本轮报告——否则'规则全坏'会被当成'代码很干净'：")
    print(st.stdout[-1500:])
    return 1
```

### W3（Critical）`include_legacy=False` 硬编码，刚修好的 20 个分析器整条腿被关掉

`engine/runner.py:117`：

```python
mode = StaticAstMode(include_legacy=False)
```

`StaticAstMode.run_legacy()`（`static_ast_mode.py:135`）实现完整、`legacy/analyzers/` 里 21 个脚本齐全，但调用点写死了 False。`summary.json` 自证：`"legacy_analyzers": 0`、`"analyzers_total": 2`。

我修好 BOM 后 selftest 显示 21 个分析器全绿（dirty 命中 116），但 `round` 一条都不用它们。**selftest 测的集合和 round 跑的集合根本不是同一个集合** —— 这正是最危险的一种错配：门禁看着是绿的，但绿的不是上场的那一队。

对照实测（`include_legacy` 打开后，只扫活的 `E:/NAS/doubao-butler/butler`）：

```
ast_defects          114 findings（37 high）
state_defects        189
concurrency_defects   20
deadcode_defects      35
────────────────────────────────
合计 358+，而 round-021 对同一目录报 0
```

**修复**：把 `include_legacy=False` 改成读 adapter 配置（`focus.yaml` 里加 `include_legacy: true`），或者在 `cmd_round` 里暴露成 CLI 参数。同时让 `run_legacy` 的产物也进 selftest 的对账集合。

### W4（High）summary 的 `zero_hit` 标记与 findings 文件矛盾

```json
"summary": {
  "zero_hit": ["generic_text"],       ← 声称 0 命中
  "total_findings": 3744              ← 实际 2014 + 1730
}
"results": {
  "generic_text": { "status": "ok", "counts": {} }   ← counts 空
}
```

`findings/generic_text.json` 里 1730 条 findings，`total_findings` 也把它们算进去了（2014+1730=3744 自洽），**唯独 `counts` 字典和 `zero_hit` 是空的**。

后果：`auditkit status` 读 `summary.json` 的趋势/台账链会得出"generic_text 这一轮 0 命中"。如果上一轮有命中，下一轮 0，台账会把这条判成 `unknown` / 规则失效。这是账实不符，且方向是**把有效规则记成死的**。

### W5（High）扫描根被判成 10-09 的快照副本，活代码被快照树稀释

**先更正我最初写错的因果链。** 我原来说"扫描根来自 `python_packages`"，那是照 `auditkit:145-155` 的 `pkg` 变量推的。但 `pkg` 算完之后**根本没被使用**：`cmd_round` 调 `run_round(repo_path=path, ...)` 传的是全仓库，`run_round` 的签名（`engine/runner.py:70-72`）里也没有接收主包的参数。**`pkg` 是 11 行死代码。**

真实扫描范围由 `StaticAstMode.scope_roots()`（`static_ast_mode.py:69-89`）决定，它叠加两个来源。实测各来源的 py 文件数（`scripts/audit_xiaoai/roots_breakdown.py`）：

```
[1] python_root          = workorders\tmp_local\b86\head_snapshot_1009\tests
                           -> 131 个 py           ← 快照树
[2] extra_gate_roots     (21 个根，前 6 个)
      _scratch_1002\butler        219 个 py
      butler                      217 个 py       ← 活代码，混在 21 个根里
      butler.local_backup         191 个 py
      tmp                         157 个 py
      ...（前 6 个小计 1098，21 个根含大量重复）

去重后总计 1009 个 py 文件（互斥分类，三项相加 == 总数）：
  快照/备份/测试树   699  (69.3%)
  活代码 butler/     217  (21.5%)
  其他（scripts 等）  93   (9.2%)

两个入口各自占比：
  [1] python_root        131  (13.0%)
  [2] extra_gate_roots   878  (87.0%)   ← 大头
```

所以病根有两处，主次分明：**`extra_gate_roots` 是大头（87%），`python_root` 是小头（13%）。**

> **勘误**：这段我原来写的是"小计 3385 / 去重后 1004 / 快照 699(69.6%) / 活代码 440"。四个数全错，而且**自相矛盾**——699 + 440 = 1139 > 1004。根因是活代码口径只排除了 `butler.local_backup`，于是 `_scratch_1002\butler`（219 个）和 `workorders\...\head_snapshot_1009\butler` 都被算成了活代码。改用完整 8 个快照标记后活代码 440 → 217，其余数字同步修正。`3385` 是旧脚本把 21 个根重复累加的结果，已弃用。

#### W5a（Critical）`extra_gate_roots` 把快照树整体捞进扫描范围

`engine/profile.py:158-170` 把 `gates.self_check_scripts` 的**父目录**当扫描根：

```python
for s in self.gates.self_check_scripts:
    d = base / Path(str(s)).parent      # ← 取脚本的父目录当扫描根
    if d.is_dir():
        out.append(d)
```

而 `core/profile.py:172-184` 探测 `self_check_scripts` 用的是**递归全仓库 glob**：

```python
for pat in ("**/audit*.py", "**/audit*.sh", "**/test_audit*.py",
            "**/*_audit.py", "**/gates.sh", "**/selfcheck*.py",
            "**/*_check.py", "**/*_selfcheck.py"):
    for p in sorted(root.glob(pat)):     # ← 命中快照树里的每一个脚本
```

后果：`_scratch_1002/butler/`、`butler.local_backup/`、`tmp/` 里每一个 `*_check.py` 的父目录都被整体加入扫描根。21 个根里大多是快照树。

**修复方向**：`self_check_scripts` 的探测只在**仓库根的第一层约定位置**找（`gates.sh`、`scripts/*.sh`、`scripts/audit*/`），不该 `**` 递归全仓。或者反过来给 `extra_gate_roots` 加一道 `_is_stale` 过滤。

#### W5b（High）`python_root` 判据本身对"有历史快照的仓库"不成立

`engine/profile.py:144-156` 判"含 `__init__.py` 的目录里 `*.py` 最多者"。实测 260 个含 `__init__.py` 的目录（`scripts/audit_xiaoai/pkg_probe.py`），两种计数都给出错误答案：

```
直接 py 数：  1. workorders\...\head_snapshot_1009\tests  127  ← 快照
             2. tests                                      93  ← 测试目录
             3. _scratch_1002\butler\api                    35
             4. butler\api                                  34  ← 活代码
递归 py 数：  1. _scratch_1002\butler                     219  ← 快照
             2. butler                                     217  ← 活代码，只差 2 个
             3. butler.local_backup                        191  ← 快照
```

直接计数让测试目录挤到第 1；递归计数让快照与活代码只差 2 个文件，排序极不稳定。

**已落地补丁 `patches/profile_py_fix.patch`**（`git apply --stat`：1 文件，56 insertions / 10 deletions）：加 `STALE_MARKS` + `_is_stale()`，改递归计数，剪掉嵌套候选，并给 `detect_python_packages` 加 `include_stale: bool = False` 默认排除。

实测效果：

```
  workorders\tmp_local\b86\head_snapshot_1009\tests  127  →  butler    217
  tests                                               93  →  （列表内唯一项，已剪掉子包）
  _scratch_1002\butler\api                            35
  butler\api                                          34
  workorders\tmp_local\b86\head_snapshot_1009\butler  34
  butler.local_backup\api                             33
```

**三处刻意的选择**（第 3 处是实测后才加的，见下）：
1. **用"包含"而非"相等"**。快照树名是复合词（`_scratch_1002`、`tmp_local`、`butler.local_backup`、`workorders`），精确匹配全部漏掉——这正是本次踩的坑。
2. **测试目录也排除**。排除快照树后 `tests` 仍居首，不排除就拿不到 `butler/`。副作用是 `tests` 里的真问题不再被规则扫到，但 `generic_text` 与 `testgap_defects` 是独立扫描根，`tests/` 仍被覆盖。
3. **改用递归计数 + 剪掉嵌套候选**。这是我第一次提交补丁后**实测抓到的 bug**：只加 `_is_stale` 而保留原来的 `glob("*.py")` 直接计数，`pkgs[0]` 会变成 `butler\api`（直接 34 个 > `butler` 直接 16 个）——扫描范围从 217 个文件缩到 **34 个（活代码覆盖率 15.7%）**，方向完全反了。递归计数让 `butler`=217 正确胜出；再剪掉被包含的候选（`butler\api`、`butler\core` 等 7 个），列表收敛到唯一一项 `butler`。

非快照候选按递归 py 数排序（`scripts/audit_xiaoai/candidates.py`）：

```
   butler            217   ← 唯一包根
   butler\api         34
   butler\core        32
   butler\skills      29
   butler\skills\engines 16
   ...共 25 个非快照候选（含 __init__.py 的目录总数 260）
```

#### 已落地补丁的端到端验证

补丁在**干净副本**（非我实验用的那份）上验证：`git apply --check` 通过，`pytest tests/` 85 passed，`python_root` 从 `workorders\...\head_snapshot_1009\tests` 变为 `butler`（217 个 py，活代码覆盖率 100%）。

跑 round-022 对比 round-021（`scripts/audit_xiaoai/compare_rounds.py`）：

```
                     round-021（修复前）   round-022（修后）   变化
  总 findings             3744               3521           -223
  快照/备份/测试树         2880  (76.9%)      2655  (75.4%)  -225  ← 全部来自快照树
  活 butler/                654  (17.5%)       654  (18.6%)    0  ← 一条未变
```

**这个结果本身是重要的负面发现**：补丁在 `python_root` 这一支上完全生效（扫描根从 131 个文件的快照树变成 217 个文件的活代码，覆盖率 15.7% → 100%），但**整轮的污染率只降了 1.5 个百分点，活代码 findings 一条没变**。

原因正是 W5a：`extra_gate_roots`（87% 污染）没动。所以本轮验证**反向印证了"补丁只触及 13% 污染"的说法**——如果那句话是估计错了，round-022 的活代码 findings 应该显著变化。

#### 勘误：我原先写的"三份独立实现"是错的

我第一次写这条时断言"`python_packages` 有三处实现，只改 `core/profile.py` 会让 `run_round` 那条腿仍走旧的 `engine/profile.py`"。**实测推翻了这个断言。**

`engine/profile.py:112`：

```python
python_packages=[dict(p) for p in (d.get("python_packages") or []) if isinstance(p, dict)]
```

它是**读** JSON，不是**算**——`ProjectProfile.from_dict()` 消费 `core/profile.py` 的产出。所以改 `core/profile.py` 会自动传导到 `run_round`，round-022 的结果就是证据（扫描根确实变了）。

准确的表述是"**一份生成 + 一份消费 + 一份死代码**"：
- `core/profile.py:detect_python_packages` —— 生成（本次补丁改的就是这里）
- `engine/profile.py:ProjectProfile.from_dict` —— 消费（无需改）
- `auditkit:145-155` 的 `pkg` —— 死代码，建议删掉

三份应收敛成一份（删掉 `cmd_round` 里的 `pkg`），否则下一个读者会再次以为要改两处。

**建议优先级**：W1（一行）→ **W5a（收益最大，87% 污染）** → W2（门禁）→ W5b（已修，只覆盖 13%）→ W3 → W4 → W6。

**一个必须点出的方法论问题**：从发现 W5 到确认"补丁只修了 13%"，中间经过了 4 轮修正（因果链判断错、目录清单不全、覆盖率低估、"三份实现"论断错）。每一轮都是我自己跑了工具才发现前一轮写错了。**这个工作流的价值恰恰在于它能让我当场证伪自己的结论**——这也正是我最初对"机器增益"存疑的地方：它不产生新缺陷，但它能证明你写的判断是错的。

### W6（Medium）`py.guard_call_swallowed` 自检未过，但被 `active` 加载

`summary.json` 的 `broken_rules: 1`：

```
py.guard_call_swallowed:
  RuleFailure(kind='dirty_miss', message='dirty 样本未命中（规则可能失效）') ×3
  RuleFailure(kind='selftest', message='3 个样本自检未通过')
```

这条规则在自己写的 dirty 样本上都没命中过，却仍以 `active` 状态参与扫描。要么补样本、要么标 `deprecated`，不该处于"自称 active 但自检红"的中间态。

---

## 四、无增益的部分：机器 findings 的精确率

### 4.1 最大规则精确率 25%

`py.silent_except_no_trace` 报 **1051 条**，抽样 40 条回溯源码四分类：

| 判定 | 条数 | 占比 |
|---|---|---|
| FP-SAFE（`except` 内有 `raise` / `logger.*` / `return err(...)` 结果信封） | 28 | 70.0% |
| FP-TEST（测试文件的假对象/占位串） | 2 | 5.0% |
| TRUE（真 `except: pass` / `except: continue`） | 10 | 25.0% |

典型 FP-SAFE 样本：

```python
try:
    body = await request.json()
except Exception:              # ← 被报"吞掉失败且无留痕"
    return err("invalid json") # ← 实际是 fail-closed 的结果信封
```

规则只看 `except` 分支里有没有 `logger` 调用，不认 `return err(...)` 这种**返回值即留痕**的契约。这个项目的 API 层大量用 `err()` 信封，所以误报率结构性偏高。

全量 1051 条 → 估计真阳性 ≈ 263 条。

### 4.2 `GEN-01-hardcoded-secret` 79 条，全在 tests/

抽样 5 条全是测试占位串：

```
tests\conftest.py:29               new_api_key="test-key"
tests\...batch97_echo_window_probe.py:170   secret = "ZZLEAKPROOFMARKER7Q"
tests\...batch136_pr_c2_auth_adoption.py:94  memory_agent_token="settings-stale-must-not-win"
```

这些是我**专门**写进测试用来验证"token 不被吞"的标记串。规则没有排除 `tests/`，也没有占位串模式识别。79 条 0 真阳性。

### 4.3 与手工审计的对照：5 个真实缺陷位置，0 命中

用 round-021 的全部 findings（3744 条）反查我上一轮报告的缺陷位置（±6 行容忍）：

| 缺陷 | 位置 | 机器命中 |
|---|---|---|
| A14 `intelligent_speaker` 内 19 行不可达死码 | `integrations/ha.py:342` | **0** |
| A7/A13 类级 `_echo_cooldown`/`_role_mode` 字典 | `core/xiaomi_ear.py:111` | **0** |
| A1 唤醒词子串匹配 + 无最长优先 | `core/dialog.py:198` | **0** |
| A4 简单规则动词表缺口 | `core/simple_rules.py:56` | **0** |
| A3 pending ask 跨房 fallback | `llm_decide/ask.py:130` | 2 条（但归到 `py.except_broad_swallow`，与缺陷无关） |

前 4 条全是 Critical/High，全在"路由语义""字符串匹配""控制流可达性"这类**跨语句语义**问题上。规则层是单函数/单节点级的 AST 模式匹配，天然看不见这类问题。这符合 `README.md` 第七节的自我声明（"静态分析候选需实测确证，AF 的 21 个确证缺陷几乎全靠实测"），但"看不见"和"报 0 命中让读者以为干净"是两回事 —— 后者是 W4 造成的。

---

## 五、结论：该不该用，怎么用

### 增益判定

| 用途 | 增益 | 理由 |
|---|---|---|
| 发现 butler 的语义/路由类缺陷 | ❌ 接近 0 | 5/5 真实缺陷 0 命中；规则是单节点 AST 模式 |
| 发现 butler 的样板类问题（吞异常/无界容器） | ⚠️ **很低** | 最大规则 1051 条里 67% 在快照树、31% 在活代码；25% 精确率 × 328 ≈ **82 条**真阳性上限，且需人工筛 |
| 审计 auditkit 工作流自身 | ✅ **显著** | W1–W6 全部是机器跑出来的，人工审计不会去看 |
| 作为门禁防止"规则坏了当成代码干净" | ✅ **必要** | 前提是先修 W2；否则门禁形同虚设 |

> 修正说明：我原来写"有 263 条左右真阳性，且 40% 在快照树"。两个数都错——263 是按**全部** 1051 条 × 25% 算的，没扣除快照树；67% 才是真实的快照树占比。只算落在活代码的 328 条时，真阳性上限是 **82 条**，比原估算低三分之一（`scripts/audit_xiaoai/rule_pollution.py` 可复现）。

### 先修什么（按性价比）

1. **W1** —— 一行 `encoding="utf-8-sig"`。不改这个，后面 5 条全部白谈。
2. **W5a** —— `extra_gate_roots` 白名单化。这是**唯一能显著改变精确率**的一步（87% 污染），其余都是修 13%。
3. **W2** —— `cmd_round` 加自检硬门。这是整个工作流唯一的安全性质，目前是建议不是约束。
4. **W3** —— `include_legacy` 从硬编码改成配置。否则 20 个分析器是死资产，且 selftest 与 round 测的不是同一队（最危险的错配）。
5. **W5b** —— `python_packages` 判据（已落地补丁，只覆盖 13%）。
6. **W4 / W6** —— 账实一致性。

**优先级依据**：只有 W5a 能改变 `live_butler` 的分母。我实测过 W5b 补丁（round-022），污染率只降 1.5 个百分点、活代码 findings 一条未变——这证明先修 W5b 是白做的。

### 长期建议

W1–W3 修完之后，这个工作流对 butler 的价值主张是：**门禁 + 样板问题粗筛**，不是缺陷发现主力。真正能出 A1/A2/A3 这类结论的仍然是人工审计 + 判别式真跑（本次我自己写的 `scripts/audit_xiaoai/repro.py`，40 行代码命中了 4 个 Critical，而 3744 条机器 findings 一条都没碰到）。

一个可执行的分工：**机器跑粗筛 → 人工按文件优先级看 `exceptions` 密度排序 → 判别式复现确证**。中间缺的环节是"按风险排序"，而当前 `summary.json` 只按规则计数，没有按文件/模块聚合。这是下一个有价值的改动点。

---

## 附录：实验可复现

```bash
# 0) 不动原仓库
cp -r /e/NAS/ADM-auditkit /tmp/auditkit_run && cd /tmp/auditkit_run

# 1) 第一步就红（复现 W1）
python auditkit selftest          # exit=1, 20 个分析器 0 命中

# 2) 修 BOM
python -c "
from pathlib import Path
for f in Path('selftest/cases').rglob('*'):
    if f.is_file() and f.read_bytes().startswith(b'\xef\xbb\xbf'):
        f.write_bytes(f.read_bytes().lstrip(b'\xef\xbb\xbf'))
"
python auditkit selftest          # exit=0, dirty 116 命中, clean 0

# 3) 画像 + 跑一轮（复现 W3/W4/W5）
python auditkit profile /e/NAS/doubao-butler --json
python auditkit round db_default --path /e/NAS/doubao-butler --round 21

# 4) 分析产物（污染/精确率/cross-check/规则级污染）
python -I scripts/audit_xiaoai/analyze_round.py       # 按源统计污染 + 交叉检查手工缺陷
python -I scripts/audit_xiaoai/precision_check.py     # 最大规则精确率抽样
python -I scripts/audit_xiaoai/rule_pollution.py      # 每条规则的快照树占比
python -I scripts/audit_xiaoai/root_probe.py          # python_root vs extra_gate_roots
python -I scripts/audit_xiaoai/roots_breakdown.py     # scope_roots 去重后互斥分类
python -I scripts/audit_xiaoai/candidates.py          # 非快照候选包排序

# 5) 验证 W5b 补丁（在另一个干净副本）
cp -r /e/NAS/ADM-auditkit /tmp/ak_verify && cd /tmp/ak_verify
git apply --check /e/NAS/doubao-butler/patches/profile_py_fix.patch
git apply /e/NAS/doubao-butler/patches/profile_py_fix.patch
python -m pytest tests/ -q          # 85 passed
python auditkit round db_fixed --path /e/NAS/doubao-butler --round 22
python -I scripts/audit_xiaoai/compare_rounds.py      # 对比 021 vs 022
```

**原仓库 `E:\NAS\ADM-auditkit` 全程未被修改**（`git diff core/profile.py` 为空；工作区仅有会话开始前已存在的改动：`scripts/yuanbao_watcher.py`、`scripts/workflow_prompt_DB.md`、`经验/`、`.browser_profile/`）。所有实验在临时副本上进行。

**交付物**：
- `patches/profile_py_fix.patch` —— W5b 补丁（56 insertions / 10 deletions，1 文件），`git apply --check` 通过、85 tests 全绿、`python_root` 从快照树变为 `butler`（217 个 py，覆盖率 100%）。**已落地但只在临时副本验证，未提交到 auditkit 仓库**——是否合入由作者决定。
- `scripts/audit_xiaoai/*.py` —— 7 个可复现脚本（本报告的每个数字都能跑出来）。

**未做的事**：
- 没修 W1（BOM）、W5a（`extra_gate_roots`）—— W5a 是收益最大的一步（87% 污染），但它要改跨项目的适配契约（`Adapter` 协议与 `scope_roots`），影响面超出一次画像函数改动，**留给作者裁**。
- 没修 W2/W3/W4/W6，只给了方案。
- 没更新 `golden.json`、没改 `projects.yaml` / `focus.yaml`。

**一个必须说清的边界**：W5b 补丁**只修了 13% 的污染**。实测 round-022 对比 round-021，污染率只降 1.5 个百分点（76.9% → 75.4%），活代码 findings 一条未变（654 → 654）。这不是补丁失效，而是它本该只覆盖这一支——如果它带来了活代码 findings 的变化，那才说明我修错了别的东西。
