# doubao-butler 小爱音箱专项审计报告

> 审计对象：E:/NAS/doubao-butler（家庭 AI 管家）
> 审计范围：小爱音箱语音链路（耳朵采集 → 对话路由 → 发声分发）
> 审计日期：2026-10-11
> 核心症状：**房间小爱执行指令后，回复不相关内容**
> 方法：分轮 + 真跑 + 读函数体（不信静态指纹）

---

## 一、结论摘要

「房间小爱执行指令后回复不相关内容」不是单点 bug，而是**语音链路三处接缝的信息丢失/错配**叠加所致，按影响排序：

| 编号 | 根因 | 位置 | 等级 |
|------|------|------|------|
| X1 | NR 老入口调用 on_wakeup 时**未传 source_device**，触发音箱身份在下游丢失 | dialog.py on_user_utterance | Critical |
| X2 | 唤醒词用**子串匹配** `w in text`，误命中后 `replace(w,'',1)` 破坏语义 | dialog.py match_role_by_text | Critical |
| X3 | room 取自**成员档案**而非**设备房间**，房间↔角色错配 | dialog.py on_user_utterance | Critical |
| X4 | 小爱原生 TTS 与 butler 并存，**仅角色命中才打断小爱**，未命中即双应答 | xiaomi_ear.py + dialog.py | High |
| X5 | 两套回声抑制并存且不一致（全局 `_echo_until` vs 设备级 `_echo_cooldown`） | dialog.py / xiaomi_ear.py | High |
| X6 | on_wakeup docstring 宣称 private 角色 bound_rooms 越界拒绝，函数体未见该校验 | dialog.py on_wakeup | High |
| X7 | 角色模式 `_role_mode` 90s 窗口内不校验成员/房间，谁说话都归该角色 | xiaomi_ear.py | Medium |
| X8 | `sensor_map` 仅在 `_connect()` 构建一次，长连接内 devices.json 变更不生效 | xiaomi_ear.py | Medium |

---

## 二、根因详证

### X1（Critical）触发音箱身份在 NR 老入口丢失

**证据** —— `butler/core/dialog.py` `on_user_utterance()` 尾部：

```python
role_id = role.id if role else "butler"
res = await self.on_wakeup(role_id, room, cleaned, member)   # ← 没有 source_device
return res.get("reply", "")
```

而 `on_wakeup(role_id, room, message, member, source_device="", source="active")`。

**为什么导致答非所问** —— `speak_as_role()` 的分发逻辑：

```python
if source_device:
    devices = [d for d in rt.devices.all() if d.id == source_device and d.enabled]
    ...
else:
    devices = rt.devices.resolve(role.output_devices, room)   # ← 走这条
```

有 source_device 时是「哪个音箱问、哪个音箱答」；丢失后回退到 `output_devices × room` 解析：
- 若 `room` 为空 → `resolve(..., None)` **不过滤房间**，角色的**所有** output_devices 一起播（客厅左右 + 电视齐响）；
- 若 `room` 错（见 X3）→ 解析到**别的房间**的音箱。

结果：用户对着书房小爱说话，答话从客厅/卧室音箱冒出来，用户感知即「回复了不相关内容 / 不知道在跟谁说话」。

**修复** —— 老入口一并透传触发设备身份：

```python
# on_user_utterance 增加 device 参数（NR payload 里的 speaker/entity 映射为 dev.id）
async def on_user_utterance(self, member: str, text: str, source_device: str = "") -> str:
    ...
    res = await self.on_wakeup(role_id, room, cleaned, member, source_device=source_device)
```

NR 侧转发时带上音箱标识；`on_event` 的 `voice` 分支从 payload 读 `device_id/speaker`。

---

### X2（Critical）唤醒词子串匹配导致误路由 + 语义破坏

**证据** —— `dialog.py match_role_by_text()`：

```python
for w in role.wake_words:
    if w and w in text:
        cleaned = text.replace(w, "", 1).strip() if w else text
        return role, cleaned
```

两重缺陷：
1. **子串匹配**：角色 `butler` 的 wake_words 含「豆包」。用户说「我买了个**豆包**」「今天吃**豆包**」都会命中，被当成点名管家。
2. **replace 破坏语义**：命中后把唤醒词**整串删掉**。若角色 wake_words 同时含「豆包」与「豆包管家」（默认角色正是如此），遍历顺序决定谁先命中——命中「豆包」时，「豆包管家帮我查天气」被清洗成「管家帮我查天气」，喂给 LLM 的入参已变形。

**修复** —— 改为「前缀锚定 + 最长匹配优先」，并只在句首剥离：

```python
def match_role_by_text(self, text: str):
    t = text.strip()
    best = None
    for role in get_runtime().roles.all():
        if not role.enabled:
            continue
        for w in role.wake_words or []:
            if not w:
                continue
            # 仅句首、且按词边界匹配
            if t.startswith(w):
                # 最长唤醒词优先，避免「豆包」截胡「豆包管家」
                if best is None or len(w) > len(best[1]):
                    best = (role, w)
    if best:
        role, w = best
        return role, t[len(w):].lstrip("，,。. ").strip()
    return None, text
```

若确需句中唤醒，改用正则 `(?:^|[，,。.\s]){w}(?:$|[，,。.\s])` 并同样取最长匹配。

---

### X3（Critical）room 取自成员档案而非设备房间，房间↔角色错配

**证据** —— `on_user_utterance()`：

```python
room = ""
mc = self.s.member_by_name(member)
if mc and mc.room:
    room = mc.room          # ← 成员「档案房间」，不是「说话所在房间」
...
if role is None and room:
    dr = self.match_role_by_room(room)   # ← 用错房间找默认角色
```

成员档案里的 room 是「这个人的常驻房间」（如 lidicn → 客厅）。但人会走动：lidicn 走进书房，对**书房小爱**说「帮我写个脚本」。此时：
- `member=lidicn` → `mc.room=客厅` → `room="客厅"`；
- `match_role_by_room("客厅")` → 客厅无 private 角色 → 回退 `butler`；
- 于是**书房的问题由客厅管家人格回答**，且发声设备按客厅解析（叠加 X1）。

反过来更糟：Kevin 跑去客厅对客厅小爱说话，`room=Kevin房间` → 命中 private 角色「凯撒」（bound_rooms=[Kevin房间]）→ **客厅小爱用凯撒人格、走 xiao_kevin 音箱应答**。

**修复** —— 房间优先级改为「设备房间 > 成员档案房间」：

```python
# 设备房间优先（设备是物理位置的可靠锚点）
room = ""
if source_device:
    dev = rt.devices.get(source_device)
    if dev and dev.room:
        room = dev.room
if not room:
    mc = self.s.member_by_name(member)
    room = (mc.room if mc else "") or ""
```

并在 `xiaomi_ear` 已传设备房间的前提下，**老入口必须同样补设备房间**，否则永远退到档案房间。

---

### X4（High）小爱原生 TTS 与 butler 并存 → 双重应答

**证据** —— `xiaomi_ear._handle_event()` 中，`wake_button`（HA `button.*_wake_up`，用于打断小爱内置 TTS）**仅在命中角色时**才按：

```python
role, cleaned = self.rt.dialog.match_role_by_text(text)
if role:
    wake_btn = getattr(dev, "wake_button", "") or ""
    if wake_btn and self.rt.ha:
        await self.rt.ha.call_service("button", "press", {"entity_id": wake_btn})
    ...
# 2. 没点名：不接话，直接 return（不按 wake_button）
```

问题：用户对小爱说一句话，**小爱同学本身会先应答**（它的云端 NLU 可能理解成别的意图，回一句不相关的话），然后 butler 才处理。若用户说的没命中唤醒词，butler 直接静默 return——用户听到的**只有小爱那句不相关的原生回复**。这正是「房间小爱执行指令后回复不相关内容」最表层的现象。

**修复** —— 明确「谁是这个房间的嘴」：
1. 若该房间小爱已被 butler 纳管（有 `wake_button`），**任何**进入 butler 的语音都在处理前先 `press wake_button` 抢占通道，抑制小爱原生应答；
2. 或在 HA 侧关闭该小爱的语音助手应答（优先方案，根治）；
3. 未命中唤醒词时，若判定用户是在对管家说话（如句首「管家/豆包」），也应抢先打断。

---

### X5（High）两套回声抑制不一致

**证据** —— 两条腿各记各的：
- `dialog.suppress_echo()` → 写**实例级** `self._echo_until`（全局单一时间戳），被 `on_user_utterance`/`on_wakeup` 开头检查；
- `XiaomiEar.note_speak()` → 写**类级** `_echo_cooldown[device_id]`（设备级），被 `_handle_event` 检查。

不一致的后果：
- `_echo_until` 是全局的：客厅播报后，**书房**的正常语音也被吞（漏答）；
- 但设备级窗口只对 `note_speak` 覆盖的设备生效，若 X1 导致 devices 解析错，抑制窗口写到错的设备 → 真正说话的那台**没被抑制** → 自己听到自己 → 自问自答。

**修复** —— 统一为设备级窗口，废弃全局 `_echo_until`；`on_user_utterance`/`on_wakeup` 改用 `XiaomiEar` 的 `_echo_cooldown.get(device_id)` 判定。

---

### X6（High）private 角色 bound_rooms 校验疑似缺失（文档-实现漂移）

**证据** —— `on_wakeup` docstring 明确写：

> - 私人助理(scope=private)校验 bound_rooms，越界拒绝；

但从读到的函数体（pending ask → skill creator → role_id 匹配 → `role = rt.roles.get(role_id)` → `role.enabled` 检查 → 记忆召回 → agent.run）**未见 bound_rooms 越界拒绝分支**。若确实缺失：客厅小爱说「贾维斯」，会走 `match_role_by_text` 命中 private 角色 jarvis，输出到 `xiao_study`（书房）——**客厅问、书房答**，典型「不相关内容」。

**修复** —— 在 role 解析后补校验：

```python
if getattr(role, "scope", "") == "private":
    br = getattr(role, "bound_rooms", []) or []
    if br and room and room not in br:
        logger.info("private role %s out of bound_rooms (room=%s), reject", role.id, room)
        return {"ok": False, "error": "out_of_room", "role": role.id}
```

（需在拿到正确 room 之后；依赖 X3 先修。）

---

### X7（Medium）角色模式窗口内不校验成员/房间

**证据** —— `xiaomi_ear._handle_event()`：

```python
mode = self._role_mode.get(dev.id)
if mode and now < mode["expires_at"]:
    ...
    mode["expires_at"] = now + self.ROLE_MODE_TIMEOUT
    await self.rt.dialog.on_wakeup(role_id, room, text, source_device=dev.id, source="xiaoai")
```

90 秒窗口内，**该设备上任何人的任何话**都交给进入模式时的角色，不校验说话人。用户「打开贾维斯」后走开，家人随口一句话会被贾维斯接管，答非所问。

**修复** —— 角色模式绑定 `member`（进入时记下），窗口内仅对同一成员续话；换人或静默超时即退出。

---

### X8（Medium）sensor_map 只在建连时构建一次

**证据** —— `XiaomiEar._connect()` 开头构建 `sensor_map`，之后 `async for msg in ws` 长循环内不再刷新。WebUI 改 devices.json 新增/改绑音箱后，须重连才生效。

**修复** —— `_handle_event` 内改用 `self.rt.devices` 实时反查（或加版本号失效重建）。

---

## 三、修复优先级与落地顺序

```
P0（先修，互相依赖）：X3（room 取设备房间）→ X1（透传 source_device）→ X6（bound_rooms 校验）
P1：X2（唤醒词前缀+最长匹配）、X4（抢断小爱原生应答）
P2：X5（统一回声抑制到设备级）、X7（角色模式绑成员）
P3：X8（sensor_map 实时化）
```

X1 与 X3 必须同批修：只补 source_device 而 room 仍取档案房间，`resolve(role.output_devices, room)` 的回退仍会错。

---

## 四、验证方案（运行时真跑，不留静态）

| 场景 | 操作 | 期望 |
|------|------|------|
| 跨房间 | 在书房对书房小爱说「管家，现在几点」 | 仅书房小爱应答，客厅静默 |
| 误命中 | 对客厅小爱说「我买了豆包」 | 不触发管家（无 wake_word 前缀） |
| 最长匹配 | 说「豆包管家，帮我查天气」 | 清洗后入参为「帮我查天气」 |
| 越界 | 对客厅小爱说「贾维斯」 | 拒绝或回退 butler，书房不响 |
| 双应答 | 对任意纳管小爱说非唤醒句 | 小爱原生不被抢答（或已被 HA 关闭） |
| 回声 | 让小爱播报长句后立即说话 | 不被误吞（漏答），也不自问自答 |

观测点：日志 `ear [entity|room]`、`emit xiaomi direct result device=`、`echo-suppressed`、`room default role` 四条。

---

## 五、方法论反思

本轮再次验证两条审计规律：

1. **高价值缺陷集中在「接缝」而非「函数内部」**。X1（入口未透传设备身份）、X3（房间来源跨层错配）都是「字段在层间传递中丢失/被替换」，单测直接调 `speak_as_role(role, text, room)` 会因为测试里 room 恰好正确而全绿绕过。
2. **文档-实现漂移是高危信号**。X6 的 docstring 白纸黑字写「校验 bound_rooms」，函数体却没有——这类「声称做了但没做」的守卫，比明显缺失更隐蔽，因为它会让复核者放心跳过。审计时对每条 docstring 里的「拒绝/校验/兜底」措辞都应回读函数体确认。

建议把小爱链路纳入固定断言：**「触发设备身份」必须在 on_event → on_user_utterance → on_wakeup → speak_as_role 全程无损传递**，任一环节丢失即测试失败。

---

## 六、附：本次审计未覆盖

- `butler/integrations/ha.py` 的 `play_xiaomi_url_once` / `schedule_xiaomi_stop` 实现细节（本轮未读函数体，X4 之外的小爱播放路径未证）；
- NR 侧 `nr_flow_butler.json` 的 payload 字段（决定 X1 能否直接透传）；
- `check_simple_command` 对小爱来源「静默吞掉设备控制」的误判边界（可能与「不相关」有交叉）。

以上三项建议下一轮补齐。
