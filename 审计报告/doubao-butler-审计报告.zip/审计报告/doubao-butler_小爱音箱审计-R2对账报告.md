# doubao-butler 小爱音箱审计 · R2 对账报告

> 轮次：R2（既有结论对账 + 发声实现层）
> 日期：2026-10-11
> 方法：先 grep tests/ 列既有批次覆盖清单，再逐项判定 R1 结论真伪
> 结论：**R1 的 8 项中，3 项为误报/已处理，1 项降级，4 项确认。**

---

## 一、为什么必须先对账

R1 在**未查 tests/ 的情况下**就宣布 8 个缺陷，违反了自己在记忆 #5 里总结的方法论。
本项目 tests/ 有 190+ 批次审计文件，直接命中小爱链路的有 6 个：

```
test_audit_1009_batch97_echo_window_probe.py    # 回声窗口探针尺
test_audit_1010_batch142_voice_reverselookup.py # 角色嗓音反查
test_audit_1010_batch156_mention_gate.py        # 没点名不接话
test_audit_1011_batch181_role_roster.py         # 角色表 6 vs 5
test_audit_1011_batch192_echo_cooldown_legs.py  # 回声冷却两把闸
test_wo_but_008_ha_exceptions.py                # HA 异常
```

---

## 二、逐项对账结果

| R1 编号 | 原判 | 对账后 | 依据 |
|---------|------|--------|------|
| X1 透传 source_device | Critical | ✅ **确认（新）** | dialog.py:193 仍无 source_device，无测试覆盖 |
| X2 唤醒词子串匹配 | Critical | ✅ **确认（新）** | dialog.py:205-209 仍是 `w in text`+replace |
| X3 room 取成员档案 | Critical | ⚠️ **降级：仅 NR 老腿** | xiaomi_ear 已用 `dev.room`；仅 on_user_utterance 受影响 |
| X4 wake_button 不抢答 | High | ✅ **确认** | ear 仅角色命中时按（191/215 行） |
| X5 回声抑制不一致 | High | ❌ **误报** | 批192 已诊断并修复：note_speak 统一、具名常量、写侧清扫 |
| X6 bound_rooms 校验缺失 | High | ⚠️ **降级 Medium** | private 角色经 match_role_by_room 按房间匹配；仅 text 腿不校验 |
| X7 角色模式不校验成员 | Medium | ❌ **误报** | 批156 明确裁定「属已点名，本件⛔动它」＝有意设计 |
| X8 sensor_map 建连一次 | Medium | ✅ 保留 | 无测试覆盖 |

---

## 三、误报详证（这是我 R1 的错）

### X5 误报：回声抑制**不是**不一致，而是「两把闸分工已定」

R1 说「两套回声抑制不一致」——真相是批192 **已经诊断过同一现象**，并明确裁定：

- **全局腿** `dialog.suppress_echo`（`secs = max(8.0, len(text)*0.4+6.0)`）**故意不改**：
  批192 docstring 原文——「它的 0.4（2.5 字/秒）是 docstring 里写明取 slow 的保守值，
  且起点在合成前——把它改窄会重新打开路线图 154『主卧室小爱回声自触发』那一格」。
  `test_16` 是**反回归**格，专门钉住「全局腿⛔被收窄」。
- **设备腿**已从「盖戳时刻+硬编码 15.0」收编为：
  `note_speak` → `until = now + max(ECHO_COOLDOWN_S, hold_s)`，写侧清扫陈旧键（ear.py:123-126）。

**判定**：R1 引用的是**修复前**的形状。现读代码已含 `note_speak` / `ECHO_COOLDOWN_S` / 清扫循环。
→ 撤销 X5，写入误报规则：「回声窗口分叉」已有 DCD 裁定与回归测试，勿重报。

### X7 误报：角色模式**是**有意设计

批156 `test_role_mode_followup_still_gets_answered` 原文注释：
> 「角色模式是用户自己『打开贾维斯』起的续话，属已点名：本件⛔动它。」

**判定**：撤销 X7。它是被明确保护的行为，不是缺陷。

### X3 降级：xiaomi_ear 腿其实是对的

`xiaomi_ear._handle_event` 里 `room = getattr(dev, "room", "")`——**取的是设备房间**，
R1 说「room 取成员档案」只对 `on_user_utterance`（NR 老腿）成立。

**判定**：X3 降级为「NR 老腿专属」，与 X1 同源（同一条 on_user_utterance 路径）。

---

## 四、确认的真缺陷（收窄后）

### X1（Critical，确认）NR 老入口丢失触发设备

```python
# dialog.py:193  —— 现状
res = await self.on_wakeup(role_id, room, cleaned, member)   # ⛔ 无 source_device

# xiaomi_ear.py:198 / :223 —— 对照（新腿是对的）
await self.rt.dialog.on_wakeup(role_id, room, text, source_device=dev.id, source="xiaoai")
```

两条腿行为不一致：新腿（HA 直连）「哪台问哪台答」，老腿（NR→`butler/event/voice`）丢失设备身份。
只要 `doc/nr_flow_butler.json` 仍在用，老腿缺陷就是活的。**R3 必读该 json 确认。**

### X2（Critical，确认）唤醒词子串匹配 + replace 破坏语义

dialog.py:205-209 原文未变：
```python
for w in role.wake_words:
    if w and w in text:
        cleaned = text.replace(w, "", 1).strip() if w else text
        return role, cleaned
```
默认角色 `wake_words=["豆包管家","豆包"]` 子串重叠 → 「我买了个豆包」误命中；
「豆包管家帮我查天气」可能被 `replace("豆包")` 截成「管家帮我查天气」。
无任何既有批次覆盖。

### X4（High，确认）wake_button 仅角色命中才按

`xiaomi_ear` 两处 `call_service("button","press",...)` 分别在 191-194（角色模式）与 215-218（唤醒词命中），
**第 228-230 行的「没点名」分支不按**。用户对小爱说的非唤醒句，小爱原生先答一句不相关的，butler 静默。
（注：batch156 只保证「butler 不接话」，未处理「小爱原生抢答」。）

### X6（降级 Medium）text 腿不校验 bound_rooms

docstring 仍写「私人助理(scope=private)校验 bound_rooms，越界拒绝」，但 `on_wakeup` 函数体无此分支。
`match_role_by_room` 只在**房间推断**时用 bound_rooms；`match_role_by_text` 命中即返回，不校验房间。
→ 客厅说「贾维斯」（wake_word 命中 jarvis，bound_rooms=[书房]）仍会被接受。

---

## 五、覆盖率更新

```
听话腿 ear      60% → 75%  （读完 note_speak/echo/mention 三分支）
说话腿 dialog   55% → 70%  （on_user_utterance 全段 + match_role 两函数）
发声腿 ha.py     8% → 45%  （读到 play_xiaomi_url_once/schedule_xiaomi_stop 主体）
NR 桥接          0% →  0%  （仍未打开 nr_flow_butler.json）
真跑            10% → 10%  （未跑）
```

---

## 六、误报规则沉淀（写入审计记忆）

1. **回声抑制「两把闸」**：全局腿 `suppress_echo` 的 0.4 系数是 DCD 裁定的保守值，
   改窄会重开路线图 154；设备腿已收编 `note_speak`。看到「两套窗口不一致」勿当新缺陷。
2. **角色模式不校验成员**：batch156 明确裁定属「已点名」续话，是保护行为。
3. **`_est_speak_secs` vs `0.4`**：两条公式**不同源是设计**，非 bug。

---

## 七、R3 待办（已收窄）

1. **`doc/nr_flow_butler.json`** —— 决定 X1/X3 老腿是否还活着（最高优先）。
2. `ha.py` 剩余：`_xiaomi_ubus` / `_play_lock` / `_refresh_xiaomi_token` / `play_xiaomi_url_once` 的 music 分支。
3. `event_stream.py` ROOM_MAP 与 `devices.json` 的 room 字段一致性。
4. `simple_rules._check_device_control` 函数体（X4 的邻居：小爱来源静默吞设备控制）。
5. R4 真跑：`python -c` 构造 `on_user_utterance` 断言 source_device 丢失。

---

## 八、方法论教训（第二轮验证）

**顺序错了就是错**：R1 应在宣布结论前先跑：
```
Select-String tests/*.py -Pattern 'echo|mention|room|source_device'
```
本次 grep 一下，就避免了 X5/X7 两条误报——这正是记忆 #3 里 memory-agent 审计 6 项误报的同型错误。
**教训固化为流程**：任何「机制类」缺陷（抑制/冷却/去重/限流），下结论前必须查 tests/ 有无同名批次。
